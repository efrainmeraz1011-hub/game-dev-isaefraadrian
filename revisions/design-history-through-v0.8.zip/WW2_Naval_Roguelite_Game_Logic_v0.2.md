# WW2 Naval Roguelite — Foundational Game-Logic Design

**Version:** 0.2 — destroyer, faction, and consequence-system revision  
**Date:** September 11, 2026  
**Working project:** WW2 FTL Game; final title undecided  
**Document purpose:** A living blueprint for gameplay, content design, prototyping, and implementation.  
**Status:** Confirmed direction: command a WWII-style destroyer; choose American or British forces on the Allied side, or German or Japanese forces on the Axis side; progress through randomized ocean sectors and locations; manage movable personnel, upgradeable ship systems, supplies, and lasting consequences; fight in pausable real time. Recognizable ship design matters more than exact historical statistics. Specific balance values, faction bonuses, campaign stories, and scope beyond those decisions remain proposals.

The player commands a destroyer through a chain of contested ocean sectors toward a final operation for their chosen faction. Each sector contains connected locations such as open-water waypoints, islands, ports, and patrol areas. The player manages a persistent crew and ship, fights or avoids surface ships, submarines, aircraft, and mines, and weighs immediate survival against the supplies and readiness needed farther ahead. Each campaign is a self-contained run with lasting consequences; future runs gain new strategic options through earned unlocks.

The structural inspiration is a branching journey, pausable real-time encounters, crew and system management, scarce supplies, procedural events, and consequential loss. The game's identity comes from naval reconnaissance, maneuver and firing bearings, compartment flooding, damage control, crew living spaces, mission obligations, weather, and replenishment. Its missions, fiction, interface, equipment, progression, and finale should be developed as original material. Convoy escort is one mission family; a convoy is not automatically attached to every run.

### Reading and maintaining this document

- **Design rule:** Intended behavior for this draft; changing it requires reviewing dependent systems.
- **Prototype value:** A starting number for testing, not a claim about WWII performance or final balance.
- **Expansion:** A future system outside the initial playable scope.
- **[OPEN ID]:** A decision needing further design. Each placeholder has a provisional default so it does not silently block the prototype.
- Distances, damage, fuel, and equipment outputs are game abstractions. Reference research may guide silhouettes, equipment appearance, and terminology; historical gun sizes or commissioning dates do not dictate balance or upgrade access in the standard ruleset.
- Use stable content identifiers for ships, systems, events, and unlocks. Record changes in Section 6.12 and update examples, formulas, save fields, and acceptance checks together.

### Contents

1. [Basic logic](#1-basic-logic)
2. [Progression](#2-progression)
3. [Saving](#3-saving)
4. [End game](#4-end-game)
5. [Replayability](#5-replayability)
6. [Factors, variances, and variables](#6-factors-variances-and-variables)

## 1. Basic logic

### 1.1 Player role, setting, and design pillars

**Player role:** The commanding officer of one destroyer. The selected faction assigns the campaign's final operation; the player controls the journey, priorities, configuration, crew assignments, and tactical orders. A campaign can involve breakthrough, interdiction, relief, escort, or rescue; the exact central story and finale remain open.

**Setting and authenticity:** A fictional WWII-inspired naval campaign. A destroyer should have a recognizable silhouette, bridge, funnels, deck weapons, internal machinery spaces, and a readable relationship between its exterior and compartment layout. Movement, firing arcs, flooding, and damage must have coherent physical causes. Exact historical performance, national technology rankings, and strict date restrictions are not required. Balance may equalize or vary equipment while preserving its visual identity. Never claim prototype statistics are historical specifications.

**Playable faction selection:** Choose side, then faction and destroyer layout. Allies include American and British choices; Axis includes German and Japanese choices. Soviet/Russian factions are outside the initial roster as a scope decision. Faction determines visual identity, names, mission framing, baseline friendly/hostile forces, service access, and starting options. It does not determine an individual's inherent skill or morale.

| Faction | Side | Confirmed distinction | Proposed starter-package emphasis, subject to testing |
|---|---|---|---|
| American | Allies | American destroyer visual identity and crew/mission presentation | Flexible loadout with an AA or repair-support option |
| British | Allies | British destroyer visual identity and crew/mission presentation | Search, sonar, or escort-control option |
| German | Axis | German destroyer visual identity and crew/mission presentation | Surface fire control or machinery-management option |
| Japanese | Axis | Japanese destroyer visual identity and crew/mission presentation | Torpedo preparation or low-signature approach option |

These package ideas are game-design alternatives, not claims of historical national superiority. Start each faction with one accessible baseline destroyer and a comparable capability budget; further layouts can be unlocked. Every faction can obtain the core radar, sonar, AA, depth-charge, and damage-control functions. Do not force a nationality into one viable playstyle.

Campaign force pools must make sense for the selected side and fictional scenario. Opposition ordinarily comes from the other side; neutral contacts and exceptional hostility require an event rule. An American run need not randomly fight a British ship, and choosing Japan must not fail because only Atlantic Allied ports were authored. Separate scenario eligibility from exact historical date restrictions.

**Design pillars:**

1. **Command under uncertainty.** Contacts begin as incomplete information; scouting and positioning can be as valuable as firepower.
2. **A ship is a connected workplace.** Crew travel through compartments; fires, flooding, power loss, and blocked passages create competing demands.
3. **Survival has an opportunity cost.** Repairs, detours, rescues, and protection consume resources or expose the force to interception.
4. **People and mission consequences matter.** Crew, allied ships, rescued personnel, and cargo when assigned affect the operation and ending.
5. **Failure teaches.** Important threats are signaled, outcomes can be explained, and unlocks create alternatives without making early losses mandatory grinding.

### 1.2 Scope and units of control

The command ship receives the full compartment and named-crew simulation. The player may also command up to two abstract escort units through orders such as screen, scout, intercept, or protect a named merchant ship. Escort crew are not individually simulated.

| Entity | Player interaction | Main state | Availability |
|---|---|---|---|
| Destroyer command ship | Full internal and tactical control | Crew, compartments, systems, hull, stability, stores | Only playable ship category in the core game; four faction identities |
| Cruisers and battleships | Allied support, enemy contacts, or operation objectives | Simplified hull, systems, weapons, and doctrine | Encounter roster; no progression into commanding them |
| Escort unit | High-level role, target, and withdrawal order | Hull, readiness, capability, endurance, ammunition | One in prototype; up to two in full design |
| Merchant convoy | Formation/protection priority; no direct weapons control | Individual hull, cargo, passengers, speed, arrival status | Escort missions or an explicitly selected convoy campaign |
| Aircraft squadron | Launch/request sortie, assign mission, recall | Available aircraft, readiness, fuel endurance, losses, mission | Reconnaissance and strike support |
| Enemy surface ship | Observed contact and tactical opponent | Corvettes, destroyers, larger warships, patrol craft; finite systems/stores | Core; composition bounded by sector and mission |
| Enemy submarine | Hidden or classified contact; antisubmarine opponent | Depth state, detection, battery, torpedoes, hull | Core |
| Player submarine | A different possible game mode | Battery, air, depth, pressure hull, stealth | Outside destroyer scope; only a separately approved future expansion |

Crew tokens represent named department leaders and small specialist teams, not every person aboard a real ship. A prototype destroyer begins with six crew tokens. Different destroyer layouts vary station placement, access routes, common areas, and staffing demands; keep the eventual range near six to ten tokens to preserve readability. Token representation is a proposed abstraction and remains open for review.

Friendly aircraft arrive from an available land base or abstract carrier ally. A destroyer coordinates their assistance; it does not carry an air wing by default. Any future ship-launched reconnaissance unit requires explicit equipment and a plausible launch/recovery representation. Each mission requires a compatible support source and scenario-appropriate aircraft. A fully managed aircraft carrier is outside core scope.

### 1.3 Core loops

**Campaign loop:**

1. Review mission status, any assigned cargo/allies, ship condition, supplies, route information, and sector threat.
2. Choose a reachable next node and inspect known travel costs and hazards.
3. Commit travel; pay its cost and advance campaign time.
4. Resolve the node's event, encounter, port service, or mission decision.
5. Stabilize the ship, choose salvage or rescue priorities, and allocate limited repairs.
6. Reassign crew, refit where allowed, and choose the next route.
7. Complete a sector objective and proceed to a new sector until the final operation.

**Tactical loop:** Observe contacts → pause and issue orders → maneuver and allocate crew/power → fire, launch, screen, or disengage → respond to damage → reassess the mission.

**Between-run loop:** Debrief → apply earned unlocks once → inspect lessons and statistics → choose a ship/doctrine/loadout → begin a new seeded campaign.

At each loop, the interface should communicate: what is known, what could change, what the player can do, and what continuing will cost.

### 1.4 Time, pause, and game states

The campaign map is decision based. Reading, planning, inspecting the ship, or leaving a menu open advances no time. Committing travel, a repair, a port service, or an event action advances the stated number of campaign hours. This is the step-based strategic layer; combat has no alternating player and enemy turns. Pausing lets the player plan while both sides remain in the same real-time simulation.

Tactical encounters use pausable real time. **Prototype:** fixed simulation steps of 0.1 seconds, normal speed at 1×, optional 2×, and full pause at 0×. Player orders issued while paused become active at the next simulation step. Enemy decisions, projectiles, fires, flooding, repairs, sortie endurance, and crew movement all stop during pause. Combat contributes its actual simulated duration to campaign time: `combat_hours = simulated_seconds / 3600`.

Do not charge combat time twice through a separate event-duration estimate. A travel event may charge a stated travel block before combat, but the encounter's duration is counted only by its tactical clock. Out-of-combat repairs and rest occur as explicit campaign actions; they are never free background simulation.

```text
PROFILE → RUN_SETUP → SECTOR_MAP
SECTOR_MAP → TRAVEL_COMMIT → NODE_RESOLUTION
NODE_RESOLUTION → EVENT | PORT | ENCOUNTER
EVENT → EVENT_RESULT | ENCOUNTER
ENCOUNTER → AFTERMATH
AFTERMATH → SECTOR_MAP | SECTOR_TRANSITION | RUN_RESOLUTION
PORT / EVENT_RESULT → SECTOR_MAP | SECTOR_TRANSITION | RUN_RESOLUTION
SECTOR_TRANSITION → SECTOR_MAP | FINAL_OPERATION
FINAL_OPERATION → AFTERMATH → RUN_RESOLUTION
RUN_RESOLUTION → DEBRIEF → PROFILE
```

Terminal checks run after each completed atomic campaign action and each completed tactical simulation step capable of changing survival or objectives. Never terminate halfway through a tactical step: resolve that step's damage and objective facts together before applying the precedence rules in Section 4.5. Saving and loading preserve the current state; they do not create an extra gameplay turn.

### 1.5 Campaign routes, convoys, and ports

Use a consistent hierarchy: **campaign → ocean sectors → locations/nodes → event or encounter**. Each sector is a directed graph with forward-only travel. **Prototype:** six sectors per run; each sector has an entry, four to six decision layers, and an exit, with two to four alternatives per decision layer. The player visits one node per layer, choosing among alternatives rather than visiting every location. Sector boundaries offer a choice between two upcoming sea sectors when the mission allows it. Reaching the final sector unlocks the campaign's final operation; clearing every map node is not required.

Locations include open-water waypoints, islands, straits, convoy rendezvous, patrol lanes, salvage sites, weather fronts, minefields, ports, anchorages, distress calls, and operation areas. Geographic location and event identity are separate: an island approach might contain a patrol, aircraft, mines, a service opportunity, or quiet passage. Randomized selection obeys scenario eligibility and threat budgets; it is not a uniform roll that can place every threat anywhere. Icons show confirmed information; uncertain nodes show evidence or a risk category rather than a falsely precise encounter identity.

**Route rules:**

- Before departure, show distance, normal fuel cost, campaign hours, convoy compatibility, known weather, and known threat. Uncertain modifiers are shown as a range or clearly labeled hazard.
- On confirming an edge, check prerequisites and commit its normal fuel/time cost atomically. Any event surcharge is a separate disclosed consequence with an explicit outcome if unaffordable.
- Committed travel cannot be canceled to reroll an arrival. Interrupted transit remembers its destination and remaining travel.
- An edge is selectable only when normal cost is affordable, unless it explicitly offers a risky emergency alternative. No negative fuel or hidden borrowing.
- Destroyer speed determines ordinary independent travel; an accompanying force uses the slowest required vessel. Convoy speed limits travel only during escort. Faster independent scouting is an explicit mission action with a convoy exposure cost when a convoy is present.
- Optional surface sorties depart from and return to the same staging node, consume time/resources, and resolve only once. Main graph routes still move forward. Surface sorties are distinct from aircraft missions.
- Convoy ships are persistent named objective entities. Surviving ships cannot regenerate between nodes, and delivered cargo cannot reappear for another reward.
- A merchant ship sunk or abandoned loses its undelivered mission cargo, except for any amount explicitly preserved in a bounded recovery opportunity by that encounter's rules. Such cargo stays attached to one recovery record until recovered or forfeited; it is never duplicated. Transferring cargo requires surviving capacity and a timed action at an appropriate node.

**Ports:** Friendly ports sell or requisition fuel, ammunition, repair parts, medical supplies, recruits, and equipment according to stock, reputation, and service capacity. Repairs and installations require time. Neutral anchorages offer limited services with explicit access conditions. Hostile ports are objectives, not shops.

Port stock and quoted offers are generated on first entry and then saved. Reopening the menu does not restock or reroll prices. Each stock unit is finite; repairs have service limits. Selling equipment returns less than its purchase price, and reputation changes never create a repeatable buy/sell profit loop.

### 1.6 Threat and campaign pressure

Sector threat represents the enemy's ability to locate and intercept the operation. It is not a fleet that visibly copies the player's route. Threat rises through elapsed operational time, conspicuous travel, noisy combat, and certain decisions; reconnaissance, deception, or a one-time intelligence objective can reduce it.

**Prototype:** `threat` ranges from 0 to 100. Thresholds at 30, 60, and 85 change patrol composition, interception probability, and port service costs. The route preview explains the current consequences. High threat must not silently delete the only required harbor or create an unavoidable equipment check.

- Map idling and pause do not raise threat.
- A departure may trigger at most one additional interception. That interception cannot recursively trigger another interception.
- Threat cannot spawn unlimited farmable enemies at one node.
- Sector transitions assign the next sector's base threat plus a capped carryover from the previous sector.
- Threshold effects are applied after the action that crossed the threshold and are visible before the next route commitment.
- Standard campaigns use threat pressure rather than an undisclosed hard timer. A timed operation may add a clearly displayed deadline and state exactly what missing it means.

### 1.7 Ship compartments, systems, and power

The command ship is a graph of connected compartments with doors, bulkheads, crew capacity, system installations, and environmental hazards. Compartments belong to bow, midship, or stern zones, with a port/starboard side where useful for damage and stability.

| System | Main purpose | Important dependencies | Failure consequence |
|---|---|---|---|
| Bridge/navigation | Orders, evasive maneuver, route efficiency | Crew, communications, power | Slower order execution and maneuver recovery |
| Propulsion | Speed, changing range, withdrawal | Machinery condition, crew, fuel | Reduced speed; total failure stops powered movement |
| Generators/distribution | Supplies electrical consumers | Machinery condition and fuel availability | Reduced available electrical output |
| Main/secondary battery | Surface combat and shore fire | Ammunition, loaders, mount condition, firing arc | Slower reload, disabled mount, or reduced accuracy |
| Torpedo station | Finite heavy attacks | Tube readiness, torpedoes, bearing solution | Lost launch capability |
| Antiaircraft battery | Defends ships against aircraft | Crew, ammo, power where required | Reduced interception effectiveness |
| Radar/lookouts/sonar | Detects and classifies contacts | Crew, equipment, conditions, power | Worse information and firing solutions |
| Fire control | Builds and maintains aiming solution | Sensors, target track, crew, power | Less reliable fire; local aiming remains possible |
| Damage-control station | Repair coordination and emergency equipment | Crew, parts, access | Lower damage-control throughput |
| Pumps | Removes floodwater | Electrical power, working pump, accessible controls | Flooding becomes harder to contain |
| Medical station | Stabilizes casualties | Medic, supplies, accessibility | Slower recovery; severe wounds may worsen |
| Radio/air coordination | Escort orders and support requests | Crew, radio condition, power | Existing orders persist; new remote orders delayed |

Electrical power uses a visible capacity budget. Each consumer has off, reduced, or full-power modes where applicable. Propulsion output is a separate mechanical capacity; it is not created by assigning spare electrical pips. Raising speed increases propulsion fuel demand and usually acoustic signature.

When generators lose output, consumers are shed in the player's saved priority order. The interface pauses by default on major power loss and shows affected systems. Unpowered weapons may retain limited local/manual function only if their equipment data explicitly permits it.

**System effectiveness:** condition, available power, required staffing, crew skill, fatigue, hazards, and temporary effects combine to determine output. A system with zero condition is disabled. Any mandatory prerequisite at zero prevents operation; positive skill bonuses cannot bypass missing ammunition, incompatible targets, or a disabled mount.

#### Upgradeable sensors and defensive compartments

There are **no energy shields**. Radar supplies information, warning time, and targeting assistance; it never absorbs a hit or becomes a regenerating health layer. Sonar has its own underwater contact role. Survival comes from detecting threats, maneuvering, screening/interception where eligible, smoke and concealment, structural protection, and containing damage after impact.

| Upgradeable component | Basic function | Proposed upgrade choices | Continuing cost or limitation |
|---|---|---|---|
| Radar | Search for eligible surface/air contacts | Longer search range, faster updates, more simultaneous tracks, or better discrimination | Power/staffing and detectable emissions; no deep-submarine targeting |
| Sonar | Passive listening and active search for eligible underwater contacts | Better bearing confidence, faster classification, improved tracking, or a dedicated search mode | Own speed/noise, environment, operator workload; active search exposes the ship |
| Lookouts | Baseline visual detection and incoming-threat warnings | Better observation equipment or specialist training | Visibility and crew assignment; preserves some function without powered sensors |
| Doors and bulkheads | Separate compartments and control passage | Stronger seals/fire resistance, quicker closure, remote controls, or zonal isolation | Installation cost, finite integrity, crew-access tradeoffs; remote operation needs power |
| Pumps and damage control | Limit hazard growth and restore function | Higher throughput, redundancy, improved shoring, or better coordination | Crew, fuel/power, parts, and equipment capacity |
| Generators/distribution | Supply electrical consumers | More capacity, efficiency, protected circuits, or emergency redundancy | Space, installation time, fuel demand, and exposure to local damage |
| Fire control and mounts | Aim, reload, and fire eligible weapons | Solution speed, accuracy, loading, or ammunition handling | Finite ammo, power/staffing, arcs, and slot limits |

The prototype uses three tiers for radar, sonar, and compartment protection, with branch choices to be tuned. Sensor state, installation tier, operational condition, staffing, and allocated power are independent. Purchasing a better radar does not repair a destroyed one or provide free full-power output.

Doors are not invulnerable walls. Closed intact boundaries reduce or block the specified fire/water transfer; damage can compromise seals or jam the opening. Remote controls fail with their circuit; reachable manual operation remains possible unless the mechanism itself is blocked. A closure preview identifies isolated crew and cut-off escape routes. Automatic closure is an editable standing order and must not silently trap crew when a safe delay is available.

Opening a route to the sea can increase flooding. Surface-ship firefighting uses suppression and isolation; opening external boundaries is not a free way to vent away a fire. Hull reinforcement and bulkhead protection remain destroyer-scale upgrades, with balance values selected for gameplay rather than historical class rankings.

### 1.8 Crew management

Each crew token has identity, role, health, fatigue, morale, skills, traits, current location, and current task. Roles include navigation, gunnery, engineering, signals, medical, and damage control. Any crew member can perform basic emergency work; specialists improve speed or efficiency.

**Crew rules:**

- A crew token occupies one compartment and performs one primary task at a time.
- Reassignment requires travel through available passages. Skill bonuses start only after arrival and task setup.
- Crew can operate a system, repair equipment, fight fire, control flooding, treat casualties, assist another team, or rest when conditions allow.
- Closing a bulkhead may slow or stop movement. Opening a dangerous boundary previews expected water/fire exposure and may require confirmation as an ordinary gameplay choice.
- An unreachable task remains queued with a visible reason; crew do not teleport or silently enter lethal compartments.
- Injuries reduce performance. At zero health, the token becomes incapacitated and receives a stabilization window if the injury is survivable; explicit catastrophic events may cause immediate death.
- Stabilization consumes time and usually a medical supply. Recovering the token for full duty requires additional treatment or port care.
- Crew death is permanent for the run. Dismissed, lost, or deceased crew do not return through generic recruitment pools.
- Fatigue grows with work and major stress, and decreases through paid-time rest. Morale responds to casualties, victories, food shortages, leadership choices, and convoy outcomes.
- Low morale applies visible performance penalties and authored events. It never introduces an unannounced random mutiny that instantly ends the run.
- Experience comes from resolving meaningful actions, with per-encounter limits; repeated repair of intentionally inflicted damage cannot farm unlimited skill.

The captain is the player's role, not a crew token whose single injury arbitrarily ends the campaign. Loss of the bridge or senior officers degrades command but permits emergency control if surviving crew and systems can support it.

#### Layouts, common areas, and watches

Every playable destroyer has its own compartment graph. Corridor length, alternate routes, compartment adjacency, station capacity, and the location of vulnerable stores must matter in play. Visually different ships should not automatically share an identical hidden layout. Existing interior geometry remains stable during a run; upgrades improve installed functions or permitted room variants rather than rebuilding the ship instantly.

| Space | Benefit and eligible use | Cost, capacity, and interruption |
|---|---|---|
| Berthing/rest area | Reduces fatigue for assigned off-duty crew | Requires a safe accessible berth and elapsed time; crew leave operational stations |
| Mess/common room | Meals and social rest recover morale toward an ordinary baseline | Limited seats; consumes available rations over time; not an instant global aura |
| Medical station | Stabilizes and treats injuries | Staff, supplies, access, and treatment time; ordinary rest cannot heal severe wounds |
| Workshop/damage-control space | Improves compatible repair throughput or prepares limited emergency gear | Technician time, parts, equipment limits; no unlimited free parts production |

**Prototype watch rules:** Save a normal watch and a battle-stations assignment. One command orders the switch, but crew still move and set up at their actual stations. A sudden attack during rest leaves some stations temporarily unmanned. Manual orders override the saved watch until the player restores it. Queued paths revalidate after doors close or hazards block access.

Fatigue is an individual accumulated burden; morale is an individual response to conditions and events. Display crew values plus a clearly labeled ship average. Neither is a spendable currency, and morale is not the same as faction reputation. Proposed thresholds: fatigue above 70 slows work, morale below 30 lowers effectiveness, and recovery removes penalties gradually. No threshold causes secret instant mutiny or permanently prevents recovery.

Common-room morale recovery targets 70/100 in the prototype; stronger morale requires events or achievements, not endless sitting. Rest reduces fatigue only for crew actually resting. Bonuses do not apply to remote stations while a token occupies the mess. Time, ration use, and threat continue during an explicit rest action; opening the room screen or reassigning a token creates no benefit by itself. Rates, seats, and upgrade costs remain tuning data.

### 1.9 Damage, fire, flooding, and repair

Damage has four related layers:

1. **Structural hull:** A ship-wide reserve. Zero hull means sinking is unavoidable and the ship enters its terminal loss state.
2. **Local condition:** Damage to specific compartments, installed systems, doors, and bulkheads.
3. **Hazards:** Fire, breaches, floodwater, smoke, and exposed electrical equipment.
4. **Stability and buoyancy:** Listing creates capsize risk, while excessive total flooding can sink even a balanced ship. Both are independent of structural hull health.

Attacks first resolve contact/aiming, hit location, and armor interaction; they then apply structural/local damage and any secondary effects. Armor reduces eligible damage but never restores hull. Critical effects require a qualifying hit and a displayed or discoverable risk; magazine protection and damage control provide counterplay.

**Fire:** Fire intensity ranges from 0 to 100 per compartment. It damages local systems and exposed crew, may damage structural hull, and can spread through eligible adjacent connections. Suppression reduces intensity; isolation reduces spread. Smoke lowers efficiency and visibility within connected spaces. There is no ship-wide oxygen meter for surface ships.

**Flooding:** Breaches admit water according to breach severity and damage-control state. Water fills compartment capacity and can propagate through open or failed boundaries. Closing intact watertight boundaries contains flow but does not erase water or repair the breach. Pumps remove water only with working equipment and required power. Emergency shoring slows ingress; permanent closure consumes parts and work.

**Stability:** Floodwater creates a weighted imbalance based on compartment side and height. The interface shows stability reserve and a critical countdown. Remaining below the critical reserve for the configured grace period causes capsize. Counterflooding trades additional total flooding for reduced imbalance and is a deliberate action with a preview.

**Loss of buoyancy:** Independently track total water as a fraction of modeled compartment capacity. Prototype: warn at 65% total flooding; reaching 80% starts a 20-second foundering countdown. The countdown continues until flooding falls below 70%, which resets it. Expiry makes sinking unavoidable even if the ship remains balanced and has positive hull. Counterflooding always contributes to this total and cannot bypass the rule.

**Repair classes:**

| Action | Where allowed | Cost | Limit |
|---|---|---|---|
| Operate extinguishers, isolate compartment | During or after combat | Crew time; finite equipment capacity where configured | Does not restore hull |
| Run pumps | During or after combat | Power/fuel and time | Does not close breaches |
| Temporary shoring | Accessible damaged compartment | Crew time; emergency capacity | Slows ingress; finite per breach |
| Repair a damaged system | Accessible compartment | Crew time and parts proportional to restored condition | Field-repair ceiling |
| Patch a breach | Accessible compartment | Parts, crew time, manageable flood level | Permanent for run unless damaged again |
| Restore structural hull | Port or explicitly equipped tender | Time and service/supply cost | Stock and facility limit |
| Full overhaul | Major port | Larger cost and time | Can remove field-repair ceilings and persistent damage |

Field repairs restore function up to a prototype ceiling of 70% of maximum system condition. They do not reduce a less-damaged system to 70%; only the amount repairable in the field is capped. Structural hull cannot be regenerated indefinitely by waiting after a battle.

Enemy withdrawal does not extinguish fires or stop sinking. Aftermath begins with a stabilization phase in which hazards and crew tasks still advance tactically, with pause available. Rewards and travel unlock only after the ship is stable or the player accepts a clearly described emergency outcome. The player may call for rescue or abandon ship when stabilization is impossible.

For ordinary campaign travel, **stable** means no active fire, no ongoing water ingress, no worsening casualty countdown, total flooding below the 65% warning level, stability reserve at least 15, and no active terminal countdown. Remaining contained water and damaged equipment persist. A ship that stays afloat only through continuous pumping does not qualify: close the ingress or use an available support action within stabilization. Residual water can be pumped out through an explicit timed/fueled recovery action. Emergency evacuation may end the run; it never freezes unresolved hazards to permit free normal travel.

### 1.10 Resources and the economy

| Resource | Spent on | Typical sources | At zero |
|---|---|---|---|
| Fuel | Travel, propulsion, generators, certain support actions | Ports, tenders, limited salvage | No fuel-powered output; emergency options apply |
| Shells by battery class | Main, secondary, and AA fire | Ports, supply ships, restricted salvage | That battery cannot fire |
| Torpedoes | Torpedo launches | Compatible ports/tenders | Tubes remain usable but empty |
| Depth-charge stores | Antisubmarine attacks | Ports, supply missions | Detection/avoidance still possible |
| Spare parts | Field repair, breach patches, upgrades | Ports, salvage, mission rewards | Containment possible; material repair unavailable |
| Medical supplies | Stabilizing/treating casualties | Ports, rescue rewards | Basic aid is slower and limited |
| Rations (`rations`) | Crew and survivor endurance over campaign time | Ports, tenders, limited recovery | Food shortfall builds gradually, limiting rest and morale; no immediate loss |
| Requisition credits | Port purchases, recruitment, services | Mission assignments, delivery, approved salvage | Only free/alternative options remain |
| Intelligence | Route reveals, deception, specific decisions | Reconnaissance, signals, recovered documents | Unknown routes remain traversable |
| Support charges | Off-map air or naval assistance | Bases, favors, sector mission rewards | Support unavailable until replenished |
| Signal flares | Short-range visual requests or illumination | Ports, tenders | Radio or other valid choices only; no free flare action |
| Smoke stores | Temporary concealment through compatible equipment | Ports, tenders | Smoke unavailable; generator-fuel cost may also apply by equipment |
| Cargo capacity | Stores, mission freight, survivors | Ship class and equipment | New cargo requires a visible tradeoff |

Requisition credits are an abstract in-run budget, not permanent unlock currency. Ammunition classes remain distinct enough to make loadouts matter; the prototype avoids tracking every historical shell caliber. Compatible ammunition never converts silently between batteries.

Resource spending checks availability before committing the action and updates inventory and action state together. A canceled order returns only resources that have not already been consumed. Ammunition is consumed at firing/launch, fuel as its associated travel or tactical use occurs, and repair parts in declared work increments. Rewards cannot exceed storage capacity without a discard, transfer, or sale decision.

Salvage is capped by what the defeated force plausibly carried in its generated loadout plus the event's declared reward pool. The player chooses among recovery tasks with time and capacity costs. Rescue can replace some salvage work, offering personnel, reputation, or mission benefits rather than guaranteeing a profitable outcome.

#### Consumption, rationing, and replenishment

Keep three categories distinct: **stocks** such as fuel and ammunition are consumed; **capacities** such as generator output and cargo space constrain allocation; **conditions** such as fatigue, morale, health, and system integrity change with use and events. The main resource display groups them accordingly. Parts, medical supplies, requisition, and limited support supplement the requested fuel, rations, ammo, and morale without requiring a separate meter for every historical consumable. Fresh water is included in rations for the prototype; a separate water system is deferred.

Rations use abstract crew-day units. Each crew token or rescued group declares a `ration_demand_equivalent`; a prototype starting crew token counts as 1. The sum represents the modeled force's food demand, not an assertion about real destroyer complements. Provisions mentioned in older drafts are now this single ration stock, not a second inventory.

```text
normal_ration_demand = sum(ration_demand_equivalent) × elapsed_campaign_hours / 24
requested_rations = normal_ration_demand × ration_policy_multiplier
consumed_rations = min(accessible_rations, requested_rations)
food_shortfall_added = normal_ration_demand - consumed_rations
```

Prototype policies are normal (1.0) and reduced (0.75). Reduced rationing extends stock but accumulates food shortfall and weakens morale/rest recovery. At zero stock, time continues to add shortfall; penalties do not reset at the next node. Record shortfall by receiving crew/group; a crew member eating does not automatically feed stranded personnel elsewhere. Sustained normal meals gradually clear individual shortfall under a configured recovery rate. Saving or toggling policy preserves accrued demand and fractional consumption.

Tactical seconds contribute their converted campaign hours to ration demand exactly once. Travel and port services contribute their stated hours. Rest, repairs, and waiting are not ration-free time skips. Before commitment, show time, consumption, and an estimated endurance range at current policy. The finite campaign uses bounded morale/fatigue penalties for deprivation; prolonged starvation mortality is outside the prototype.

Replenishment requires a friendly/eligible service source, compatible stock, payment or entitlement, transfer capacity, and time. At-sea transfer ties up the receiving ship and may expose it to a declared threat. Delivered portions remain aboard if a transfer is interrupted; undelivered stock stays at its source. The source and receiving vessel update atomically, preventing duplication. Reloading or a sector transition never automatically refills ammo, fuel, or rations.

Store location also matters: defined hits or fires in magazines, fuel storage, and supply lockers can destroy a bounded amount of the actual local stock. Protected stowage reduces that risk. The UI and cause log record the lost units; the same blast cannot debit them twice. Secondary explosions require a declared, telegraphed critical condition and a bounded effect chain, not unlimited recursive detonations.

### 1.11 Tactical encounters: movement, detection, and targeting

**Presentation:** A compact sea chart shows relative ship positions, heading, range bands, visible contacts, aircraft, torpedo tracks when detected, and mission zones. A linked cutaway shows the command ship's crew and damage. Both views represent the same simulation.

The engagement display must make concurrent problems readable: target/own reload progress, ammunition per queued volley, detected incoming torpedo bearing and estimated arrival, air-attack warnings, fuel burn at current speed, crew paths, fires, flooding, power shortfalls, and withdrawal progress. Show uncertainty when an attack track is incomplete. An unobserved torpedo is not revealed by an omniscient warning; an appropriate detection cue enables a response.

Pause is available during every nonterminal tactical phase. Orders can be changed while paused, but existing shells, reload progress, committed ammunition, and contact history remain. Default optional auto-pause triggers include a newly detected torpedo, critical fire/flooding, lost propulsion, or a major casualty. The player can toggle these and restore normal speed after a warning. Gun auto-fire and target priorities are explicit standing orders; switching targets does not restart or complete reloads for free.

**Movement:** Ships have heading, actual speed, requested speed, turning limits, and a destination or maneuver order. Orders include close, maintain range, open range, turn to bearing, screen ally, and follow convoy. Changing heading takes time and may expose a broadside or temporarily spoil a firing solution. Ships do not teleport between range bands.

**Contact states:** `unobserved → suspected → detected → classified → tracked`; contact quality can decay when observations stop. A last-known marker is distinct from a current track. Passive observation is harder to notice; active search can improve detection while revealing the searcher's presence.

**Eligibility precedes accuracy:** A weapon must be compatible with the target's type and depth, have a valid bearing/range, be operational, possess ammunition, and meet its minimum contact requirement. Better accuracy cannot make a surface shell hit a deeply submerged submarine. Area searches or suppression can target a location only when the action explicitly supports it.

**Attack sequence:**

1. Accept a target or search area and validate the order.
2. Train the mount/build a solution while prerequisites hold.
3. At firing, recheck prerequisites, consume ammunition, and create the attack/projectile.
4. Resolve travel and any eligible interception or evasion.
5. Resolve hit and damage; apply local effects and update contact information.
6. Reload according to mount, crew, damage, and ammunition conditions.

Surface gunnery uses range, target profile, maneuver, weather, track quality, mount condition, and crew/fire-control quality. Player targeting can emphasize a ship zone or known system at an accuracy cost; exact compartment hits are not guaranteed. Torpedoes have travel time and directional threat, making screening, course changes, and launch timing consequential.

### 1.12 Submarines, aircraft, and combined threats

**Submarines:** Enemy submarines use surface, periscope, and deep states. Each state changes speed, visibility, vulnerability, and available attacks. They have finite torpedoes and battery endurance. A submarine cannot remain indefinitely undetectable while attacking without constraints.

- Lookouts, reconnaissance aircraft, radar, and sonar have different eligible detection conditions.
- Active sonar improves search but can reveal the searcher's location. High own-ship speed reduces useful sonar performance in the proposed abstraction.
- A classified contact enables a better attack solution; lost contact creates a last-known search area.
- Depth charges require compatible equipment and a close approach to the estimated contact area. They are not guided weapons.
- A force without antisubmarine weapons can evade, screen the convoy, request support, or fulfill a survival objective. Mandatory progression never requires sinking a deep submarine without a reachable counter.
- Disengaged submarines can affect later authored nodes only through a saved pursuit flag, not by spawning infinite immediate rematches.

**Aircraft:** Squadrons perform reconnaissance, fighter cover, antiship strike, or antisubmarine patrol if their type supports the mission. A sortie has preparation time, travel time, on-station endurance, return/recovery time, and possible losses. Support sources have range limits and finite available sorties.

The sortie state machine is `ready → preparing → outbound → on_station → returning → servicing → ready`, with explicit destroyed, diverted, and abandoned branches. Preparation reserves aircraft; dispatch consumes the listed support charge and launch stores exactly once. Canceling before dispatch releases only unspent reservations. Recovery restores surviving aircraft to the source after servicing; it does not regenerate a spent support charge. Charges are replenished only by a declared service or reward. Aircraft automatically begin returning at the endurance margin needed to reach an eligible recovery source; unexpected depletion resolves a declared diversion, ditching, or loss outcome.

- Aircraft launch only if source, weather, readiness, supply, and command prerequisites permit it.
- Loss of communications blocks or delays new orders but does not erase aircraft already airborne.
- Recall returns surviving aircraft after transit; it does not instantly restore a support charge.
- Lost aircraft reduce squadron strength until replenished at a capable source. Forced diversions or loss of the recovery source have declared outcomes.
- AA ammunition and fighter endurance are finite. Cover can prioritize flagship, escorts, or convoy ships.
- Aircraft and ships may attack together, but the encounter's threat budget accounts for their overlap. Early sectors do not stack every counter-demand at once.

#### Encounter families and mine logic

| Threat family | Main danger | Meaningful responses | Likely continuing cost |
|---|---|---|---|
| Corvette/patrol craft | Harassment, pursuit, or screening a larger threat | Guns, maneuver, intimidation/withdrawal when offered | Shells, time, possible exposure |
| Destroyer | Guns, torpedoes, maneuver, coordinated attacks | Bearing changes, concentrated fire, torpedoes, disengagement | Ammo, fuel, damage-control stores |
| Cruiser/battleship or protected formation | A costly surface threat or operation obstacle | Avoid, exploit objective windows, call support, or commit a suitable build | Major expenditure if fought; no mandatory unsupported kill |
| Submarine | Hidden approach and finite torpedo attacks | Sonar search, depth charges, evasion, screening, eligible support | Depth-charge stock, search time, noise, fuel |
| Aircraft | Bombing, aerial torpedoes, or exposed-position attacks by eligible aircraft | AA, fighter support, turns/speed changes, concealment | AA stores, fuel, smoke/support charges |
| Minefield | Local movement hazard and hull/flooding damage | Observe, slow, reroute, follow a surveyed lane, or use available clearance support | Time, fuel detour, specialist stores/support, exposure |

The initial mine model uses persistent placed contact hazards with armed/identified/cleared/detonated states. A detonated mine is consumed once. More complex influence-triggered mines are an optional later variant with explicit trigger rules; they are not introduced through unexplained damage rolls.

Mine intelligence comes from charts, lookouts under eligible conditions, survey events, or specialized clearance support. Radar and ordinary sonar are not universal mine-reveal buttons. Before an unavoidable hazardous crossing, provide a navigable response window or an alternative cost; warning quality can remain incomplete. A surprise mine encounter must still offer a signaled response opportunity rather than immediately demanding nonexistent clearance equipment.

Entering a detected field pauses by default and shows the identified hazards, uncertain areas, last known safe lane, and available responses. Slower movement gives more decision time and may improve the relevant search method, but a physical collision still detonates a live contact mine; speed is not immunity. Rerouting consumes travel cost. Clearance requires compatible capability and consumes its stated time/stores; shelling a mine is only allowed for a positively located, eligible target. The player can attempt passage without clearing every mine.

Record cleared lanes and remaining mines in the encounter state. Reentering a permitted local area does not repopulate its mines. Friendly and enemy units obey the same trigger rules and use their own knowledge of safe routes. When an aircraft raid or submarine shares a mine area, allocate a single combined threat budget and validate at least one feasible response before presenting the encounter.

### 1.13 Missions, enemy behavior, retreat, and loss of mobility

Encounters are authored objective templates populated by the generator. Objectives include survive until exit, escort merchants through a danger zone, evade detection, rescue survivors, disable a raider, sink a designated target, scout an approach, clear a mine corridor, and suppress coastal defenses.

Each encounter declares:

- Primary and optional objectives, eligibility, and any time limit.
- Which ships must survive, which cargo must arrive, and how success is registered.
- What information is initially known and what can be discovered.
- Reinforcement budget, warning, and maximum wave count.
- Victory, withdrawal, partial-success, and local-failure outcomes.
- Whether local failure ends the campaign or permits continuation with a consequence.

Enemies select goals using doctrine: raiders prioritize merchants; hunters pursue vulnerable ships; escorts protect their assigned unit; cautious forces disengage when their mission or survival threshold is reached. They obey their own finite ammunition, sensors, weapon eligibility, and movement limits. Enemy knowledge is based on observations and doctrine, not unrestricted access to hidden player state.

**Ordinary withdrawal:** Issue disengage, maintain a valid escape course, and build separation until the encounter's withdrawal meter completes. Speed advantage, concealment, and smoke help; enemy tracking and close pursuit hinder. Escape requires a traversable boundary or mission exit. The player sees the current progress and blockers. Some finales use an extraction corridor instead of generic retreat, disclosed before commitment.

**Immobility and empty stores:**

- If propulsion is disabled, crew can attempt repair while other systems continue functioning.
- A viable friendly tow requires an available capable ally, sufficient fuel aboard the towing vessel or explicitly transferred to it, available time, and conditions that permit it. Towing has limited capacity and may expose that ally.
- Limited auxiliary power may support essential pumps/radio after main fuel or generator loss; its finite emergency reserve is shown separately and cannot drive normal travel.
- At a stranded map node, emergency requisition/tow is available only through a declared campaign service; it has a finite use count and explicit cost in time, reputation, cargo, or score.
- Without a viable recovery, the player can request rescue, surrender where allowed, or abandon ship. Those actions resolve the run and debrief; the game must never require waiting forever.
- Empty ammunition alone is not a terminal condition. Avoidance and withdrawal remain meaningful where circumstances permit.

### 1.14 Procedural events and choice resolution

Events are designed templates with variable details, not unrestricted generated prose deciding mechanical outcomes. A selected event contains entry conditions, text, choices, costs, probabilities, state changes, follow-up flags, and fallback behavior.

Choices fall into standard, skill/equipment-enabled, resource-spending, risk-taking, and refusal/withdrawal categories. Special options reward preparation but are not always superior. Locked options show their missing prerequisite; hidden options should be rare and reserved for discoveries whose absence is not confusing.

Before commitment, show guaranteed costs, known outcomes, risk categories, and which important information remains uncertain. Exact percentages may be revealed by relevant expertise; the rules must not describe a dangerous choice as safe. Commit the choice and its random result before displaying the result, so reopening the event cannot reroll it.

**Example: damaged tanker in a patrol lane.**

- Rescue the crew: spend time and available passenger capacity; gain survivors and a reputation opportunity; sector threat rises with time.
- Recover fuel: requires a functioning transfer capability or equipment-enabled option; fuel reward is capped by remaining tanker stock and player capacity; a disclosed hazard may start an encounter.
- Attempt both: only available with enough time/capacity and extra equipment; incurs higher exposure.
- Pass coordinates to a friendly service: requires radio and local coverage; gains less immediate credit and records an unresolved rescue flag.
- Leave: preserves resources; records the stated mission or reputation consequence.

All variants share one persistent event instance. The tanker cannot be harvested repeatedly by returning to a menu.

### 1.15 Signals, emissions, and unwanted attention

Information has physical reach and a cost. A signal does not spawn an ally instantly or guarantee a hostile encounter; it creates an observable event that eligible nearby actors can detect, interpret, and act on. Keep local contact exposure separate from longer-term sector threat.

| Action | Intended benefit | Exposure or tradeoff |
|---|---|---|
| Visual signal flare | Request assistance from an eligible nearby ally or illuminate a limited area | Consumes a flare; visible to eligible enemies too; weather/range limit receipt |
| Radio request | Reach an in-range base/ally, request support, report a contact | Requires working radio and a recipient; hostile interception may create a bearing/pursuit clue |
| Active radar | Earlier eligible surface/air detection and better updates | Uses power and may be noticed by an eligible opposing receiver |
| Active sonar | Improve underwater search/classification | Uses power/operator effort and reveals an acoustic search cue |
| Smoke | Temporarily disrupt eligible sight/aiming | Uses finite stores, can obstruct friendly observation, and does not block every sensor |
| High-speed evasive course | Improve position against a particular attack | Burns extra fuel, can worsen own sonar search, and may add wake/noise exposure |

**Signal resolution contract:**

1. Before commitment, show inventory cost, intended receiver/coverage, response conditions, and known exposure; where recipient location is uncertain, say assistance is uncertain.
2. On launch/transmission, spend the resource once and create a signal with source, location, channel, strength, lifetime, intended meaning, and a unique action ID.
3. Eligible allies and enemies evaluate reception through their own range, equipment, environmental conditions, and knowledge. Receiving a flare alone gives a location cue, not perfect identification or a complete firing solution.
4. A friendly response requires a compatible available unit and travel/preparation time. Reserve its promised support once. A flare is separate from any support charge required to dispatch that unit; disclose both.
5. Enemy reception may improve a contact, redirect an existing patrol, enable one authored reinforcement response, or add a bounded pursuit flag affecting later location selection. The signal's committed random results and responses are saved.
6. Effects expire or are consumed under their own rules. Repeated signals consume repeated stock but do not create duplicate promises from one ally or reset completed rewards. Repeated emissions while already exposed cannot reset the enemy to ignorance.

Use finite encounter reinforcement budgets. A response must be backed by a scenario force or a bounded campaign response pool, with a declared arrival delay. Signal consequences share the existing extra-interception limit; they cannot stack a second independent infinite ambush system. If an action produces both local exposure and sector threat, present them as two distinct consequences and apply each once.

### 1.16 Causes, consequences, and carryover

Every consequential action must declare **requirements → immediate cost → execution time → intended effect → risks → persistent changes → recovery options**. A later encounter reads the actual state left by earlier choices; starting a fresh combat scene resets neither inventory nor crew condition.

| Decision | Immediate effect | What can matter later | Recovery or mitigation |
|---|---|---|---|
| Use depth charges to pursue a submarine | Spend finite charges and search/approach time; chance to remove a threat | Fewer charges at the next contact; noise may expose the searcher | Resupply, conserve remaining charges, evade, or request available support |
| Burn fuel evading aircraft | Improve a particular maneuver while consuming extra fuel | Shorter route endurance and less emergency maneuver time | Slow economical travel afterward, select a tender/port, or pay for distress aid |
| Fire a flare | Consume one flare and expose a visible signal | Help may arrive; an eligible hostile patrol may gain a clue or pursue | Limit repeat signals, relocate, use concealment, or accept the engagement |
| Fire long AA bursts | Improve eligible air defense | Lower ammunition reserves; finite magazine stock | Shorter bursts, priority targeting, fighter cover, replenishment |
| Close an upgraded bulkhead | Limit fire/water transfer | Isolated crew or a longer route to a damaged system | Reopen after containment or use an alternate path |
| Put a gunner in the mess/rest area | Recover morale/fatigue over time | Reduced weapon staffing until recall, travel, and setup complete | Rotate watches or accept slower firing during recovery |
| Reduce rations | Extend food endurance | Accumulated shortfall, slower recovery, morale pressure | Restore normal feeding and allocate recovery time |
| Run active sensors continuously | Better eligible contact information | Power/fuel demand and an emission history visible to equipped enemies | Intermittent search, passive observation, trade reduced information for concealment |
| Delay at a damaged supply ship | Gain eligible stores through a timed transfer | Increased exposure and fewer hours before the next threat tier | Take only essential stores or leave before the next transfer installment |

The HUD previews known costs and projected remaining stock; the action log records what actually happened. Keep the player's log limited to observable evidence: it may report a transmission and later detected pursuit without immediately revealing a hidden submarine's reception. The end-of-run debrief can explain a discovered or retrospectively revealed chain.

**Illustrative arithmetic, not balanced values:** Start this decision sequence with 12 depth charges and 60 fuel. Two attack patterns spending 3 charges each leave 6 charges. An evasive maneuver's complete metered fuel cost is 8, including its machinery use, leaving 52. If the previewed next leg costs 45 and no other fuel is spent first, only 7 remain for combat/recovery after arrival. Firing one of 2 flares leaves 1 whether or not help arrives. The interface must not refund these costs because the battle ended or the target escaped. Enemy interception remains conditional on its eligible reception; this example does not guarantee an ambush.

### 1.17 Functional coverage and naval adaptations

Use this checklist to cover the desired ship-management experience while choosing naval rules for each function. It is not a requirement to reproduce every science-fiction mechanic literally.

| Player-facing function | Naval implementation or scope decision |
|---|---|
| Weapon choice, charging/reload, aiming, ammunition | Guns, torpedoes, AA, depth charges, mount readiness, and fire control |
| Propulsion and escape | Machinery, fuel, speed, steering, maneuver, and disengagement |
| Power distribution and upgrades | Generators, electrical allocation, protected circuits, emergency reserve |
| Threat information | Lookouts, upgradeable radar/sonar, contact quality, intelligence, uncertainty |
| Protection and survival | Evasion, screening, concealment, eligible AA, structural protection, fire/flood control; no shields |
| Crew movement and station bonuses | Named crew/team tokens, compartment paths, watches, specialties, fatigue/morale |
| Doors and environmental control | Upgraded boundaries, isolation, pumps, suppression, safe access; no vacuum-vent shortcut |
| Healing and rest | Medical station, supplies, berths, mess/common areas |
| Supplemental automated/support capability | Abstract escort orders and finite allied aircraft missions |
| Concealment and interference | Smoke, low-signature operation, decoys where equipped, and damage to enemy sensors/radio; no magical invisibility |
| Boarding and capture | Proposed optional event after disabling a vessel: commit crew, boats/time, and risk while weakening own staffing; full real-time boarding deferred |
| Recruitment, stores, equipment, and repair stops | Friendly/neutral services, tenders, finite stock, requisition, installation time |
| Branching travel, events, quests, final operation | Ocean sectors and locations, authored procedural templates, faction contracts, saved consequences |
| Unlocks and repeat runs | Additional destroyer layouts/doctrines, meaningful failures, seeds, debrief, permanent run consequences |

Teleportation, crew resurrection, and supernatural crew control have no core naval replacement. Future boarding, sabotage, or deception must have visible travel, access, equipment, and timing constraints. They remain explicit open features rather than silent missing systems.

## 2. Progression

### 2.1 Run setup and starting choices

A new run selects side, one of its two factions, a compatible destroyer layout, campaign, difficulty, starting doctrine, and loadout. Show the final objective, baseline friendly/hostile forces, faction package tradeoffs, and starting supply endurance before commitment. The seed may be random or user-entered. Rules/content versions, faction/scenario eligibility, and gameplay-affecting unlock eligibility are recorded with it.

The default first run begins with a destroyer, six crew tokens covering core functions, modest spare parts and medical supplies, one limited support option, and enough fuel for the generated sector's baseline route plus a displayed safety margin. A starter battery can address the initial surface threats. Specialist threats are introduced with an avoidance route or accessible countermeasure.

Starting inventory is derived from the chosen destroyer layout and generated route costs. No faction starts with a mechanically impossible route because its visual design has a different capacity profile. Loadouts trade among fuel endurance, ammunition, sensors, protection, common-area capacity, and support; the player cannot exceed slot, weight, electrical, or cargo limits.

The first encounter teaches pause, assignment, detection, firing, and damage control in a low-complexity situation. Optional tutorial protection is declared as a ruleset, not secretly applied to standard play.

### 2.2 Sector campaign arc

| Sector | Learning/pressure focus | Example sector objective | Progression opportunity |
|---|---|---|---|
| 1. Assembly waters | Core controls, basic gunnery, resource previews | Reach the assigned staging point | First refit and crew specialization |
| 2. Contested passage | Ambiguous contacts, sonar, alternative routes | Cross a patrol belt, with an optional escort assignment | Sensor or antisubmarine choice |
| 3. Open-ocean crossing | Endurance, weather, rest, salvage/rescue | Reach a limited resupply point | Fuel efficiency or damage-control investment |
| 4. Coastal approaches | Aircraft, mines, shore threats, port access | Open one of two approach corridors | AA, scouting, or allied-support investment |
| 5. Blockade perimeter | Combined threats and mission consequences | Secure intelligence or weaken defenses | Final preparation and specialist services |
| 6. Final operation | Multi-stage objective using accumulated choices | Complete the declared faction mission and secure the destroyer | Campaign resolution |

These labels describe fictional gameplay sectors, not a required Atlantic itinerary. Geography, ports, opponents, and mission language adapt to the chosen faction and scenario while sharing the same progression rules. A first complete run targets approximately 120–180 minutes, with shorter scenario modes considered after pacing tests. The exact sector count and duration remain proposed tuning values.

### 2.3 Within-run growth

Progression has four parallel tracks:

1. **Ship capability:** Destroyer-compatible mounts, radar, sonar, generators, pumps, doors/bulkheads, crew living spaces, storage, and emergency equipment.
2. **Crew capability:** Specializations and experience that improve tasks or open event options.
3. **Operational position:** Intelligence, reputation, port access, assigned-allies/cargo condition, and support availability.
4. **Campaign commitments:** Mission flags and choices that alter later opportunities and the finale.

Upgrades must change decisions, not only add percentage bonuses. Better sonar can enable earlier classification; improved pumps can keep a damaged section usable; extra AA trades cargo/power for convoy protection; increased fuel capacity uses space otherwise available for stores or survivors.

### 2.4 Equipment, upgrades, and compatibility

Every equipment definition includes compatible ship classes, slot type, installation requirements, mass/capacity cost, electrical demand, ammunition/fuel requirements, base performance, upgrade branches, and salvage value.

- Major installation requires a capable port or tender and an explicit time cost.
- Minor field configuration may be performed only outside tactical danger with its stated cost.
- Upgrades have three prototype tiers and at least one mutually exclusive specialization where it creates a useful choice.
- Replacing equipment puts the old item into storage only if capacity permits; otherwise sell, discard, or cancel before commitment.
- Installation previews peak required power and any staffing shortfall. The player may accept an underpowered optional system, but the interface explains the limitation.
- Class limits prevent a destroyer from mounting battleship-scale batteries or arbitrary carrier facilities.
- No individual ship can equip the strongest option for every threat simultaneously.

**Example branches:** fire-control accuracy versus faster solution acquisition; stronger bulkheads versus higher pump throughput; long-range reconnaissance versus more frequent short patrols; economical propulsion versus greater emergency speed.

### 2.5 Crew development and recruitment

Crew improve through meaningful work, mission completions, training at ports, and event outcomes. Each skill has a bounded progression curve; two prototype specialization choices occur during a typical surviving run. Cross-training is possible but costs time or forgoes a stronger specialty.

Recruitment pools are finite and persistent per port. New recruits have roles and tradeoffs appropriate to campaign stage, allowing recovery from casualties without guaranteeing an immediate perfect replacement. No mandatory objective requires one unique named person to remain alive unless the mission clearly established that person as an objective.

### 2.6 Difficulty growth and mission consequences

Later sectors increase encounter budgets, enemy coordination, mixed-threat frequency, logistics pressure, and objective complexity. Enemy strength is based on sector, difficulty, threat, and template; it does not secretly grow to exactly cancel the player's newly purchased upgrade.

Optional high-risk routes offer greater opportunity with a visible threat profile. A difficult encounter is not guaranteed to repay its repair bill. Safer routes may have lower rewards or higher travel costs, but should remain legitimate strategies.

Earlier choices alter later content through declared flags: rescued specialists may staff a port; scouting may expose a mine lane; abandoning an escort may reduce final screening; sparing a neutral vessel may preserve harbor access. Effects should be bounded and understandable from the debrief, even when the exact future event was not predictable.

### 2.7 Between-run progression

Permanent progression primarily unlocks alternatives: additional destroyer layouts, doctrines, optional equipment packages, campaigns, challenge rules, and contextual codex entries. All four factions have a baseline starting option; nationality is not gated behind another faction's campaign completion. Persistent numerical hull, damage, or resource bonuses are excluded from the default design. The within-run arc is improving the selected destroyer, not replacing it with a cruiser or battleship.

Unlocks use explicit achievement predicates, such as completing a sector rescue chain, finishing a run with a damaged but surviving convoy, or reaching a milestone with an unfamiliar doctrine. Unlock progress is checkpointed as it is earned and applied idempotently; a crash cannot duplicate it or erase already committed credit.

Losses may unlock discoveries and demonstrated milestones. They do not grant endless purchasable power for deliberately restarting at the first encounter. Every base campaign must be winnable using its initial available ship and equipment pool.

### 2.8 Implementation milestones and scope gates

| Milestone | Included | Exit criteria |
|---|---|---|
| A. Combat sandbox | One destroyer, six crew, compartments, surface enemy, pause, shells, fire/flooding, retreat | Orders, hazards, damage, and loss resolve consistently |
| B. Vertical slice | One branching ocean sector, optional merchant objective/escort, port and replenishment, roughly 12 events, submarine and air threats, a basic minefield, flare consequences, mess/rest assignments, suspend/resume | A mini-run demonstrates supply carryover and meaningful route/crew choices |
| C. Full campaign | Six-sector progression, declared finale, American/British/German/Japanese destroyer options, full crew growth, meta-unlocks | Each faction can complete a valid campaign; victory/loss/withdrawal and saving work end to end |
| D. Content and balance | Broader event pool, mixed threats, accessibility, difficulty tuning | Diverse approaches can win; major outcomes are explainable |
| E. Expansion candidates | Additional scenarios, destroyer layouts, advanced mine types, challenge campaigns; other command-ship categories only by a later scope decision | Separate approved specification for each addition |

The full blueprint is the intended direction; the vertical slice deliberately implements a smaller portion. [OPEN SCOPE-01: confirm campaign length and number of destroyer layouts after the vertical slice.] Confirmed core roster: four faction choices, destroyer command only. Provisional production scope: one reusable fictional sector-campaign structure with faction-appropriate force pools and presentation, expanding geography only as content capacity permits.

## 3. Saving

### 3.1 Player-facing save policy

The default campaign uses one continuing save per active run and permanent consequences within that run. The player may suspend at any time, including during combat, and resume as often as needed. Closing the application never counts as death, withdrawal, or abandoned aircraft; no simulation time passes while the application is closed.

There is no player-selectable checkpoint rollback in standard play. Suspend saves are continuation points and are not deleted when loaded. A completed or lost run becomes an archived debrief and cannot be resumed as an active standard campaign.

An optional practice mode may allow manual checkpoints and altered rules. Its results are labeled separately; accessibility settings that change presentation, input, or pause behavior do not automatically turn a campaign into practice mode.

### 3.2 Profile state versus run state

| Record | Required contents |
|---|---|
| Profile | Profile ID, settings, accessibility preferences, discovered entries, unlocked starting options, challenge progress, run history, processed reward/terminal transaction IDs |
| Run identity | Run ID, profile ID, side/faction ID, destroyer/layout ID, campaign and objective-contract ID, initial seed, generation version, save schema version, content version, ruleset, difficulty, starting choices, eligible content manifest |
| Campaign state | Generated sectors/edges, current location or transit, active state/phase including aftermath stabilization or reward selection, discovered information, campaign hours, threat, port stock/prices, relations, mission flags, deadlines, objective cargo ledger |
| Player force | Destroyer and equipment, crew identity/skills/health/tasks/morale/fatigue/food shortfall, living-space assignments, watch plans, local hazards, power/sensor modes, inventories and ration policy, optional escorts/convoys/cargo, squads/support sources |
| Tactical state | Simulation tick, positions/headings/speeds, contact knowledge for each side, projectile/torpedo entities, mines/cleared lanes, flares/smoke and expiry, signal recipients/interception flags, aircraft missions, reloads, targets, orders, AI state, retreat and objective timers |
| Pending work | Crew paths and setup progress, repairs already paid for, port/partial-transfer contracts, event commitments, unclaimed rewards, interrupted transit, aircraft recovery, pending signal responses, accumulated fractional fuel/ration use |
| Randomness | Separate random-stream states/counters for map, events, combat, rewards, and cosmetic presentation where used |
| Reliability metadata | Save generation number, checksum, timestamp, previous valid generation, journaled transaction IDs, terminal-processing status |

Current-run fuel, crew, equipment, and mission cargo never become profile inventory. Profile unlocks change eligibility for later run setup; they do not mutate a run already in progress.

### 3.3 Save triggers and transactions

Save at run creation, node arrival, sector transitions, event choice commitment, resource purchases/sales, installation commitment/completion, completed reward decisions, encounter entry/exit, explicit suspension, and terminal outcome determination. In active tactical play, create a rolling snapshot approximately every 15 simulated seconds at a completed tick boundary.

A state-changing choice uses one transaction:

1. Validate it against the current state and inventory.
2. Assign a unique action ID and determine any random result that becomes committed now.
3. Build the updated state, including resource changes, flags, and random-stream counters.
4. Write a new durable save generation or journal record atomically.
5. Only then reveal the committed result and permit the next dependent choice.

Travel keeps a last valid pre-action generation for technical recovery, while normal continuation loads the newest committed action. Port services save both payment and remaining service time; reloading cannot obtain the service without its cost or pay twice.

For periodic tactical snapshots, serialize all relevant state from one completed simulation tick. Do not mix a projectile from one tick with a target position or inventory from another. A normal suspend waits for its save to finish and confirms completion before closing.

### 3.4 Randomness and resume fidelity

Map generation, event selection, combat outcomes, and rewards use separate deterministic random streams. Cosmetic effects cannot consume gameplay randomness. Save the streams' current states or reproducible counters, not only the initial seed.

The same initial seed reproduces initial content only when campaign, generator/content/rules versions, difficulty, starting choices, and eligible content match. Combat still depends on player actions and their timing. Saving mid-salvo and resuming from that state with the same subsequent commands must reproduce the same simulation under the same supported build.

Events, shops, and reward offers already generated retain their exact contents. A selected event outcome is stored before it is shown. Loading cannot reroll it by reopening an interface or moving crew after commitment.

### 3.5 Permanent loss and terminal processing

Use a monotonic run lifecycle:

```text
ACTIVE → TERMINAL_PENDING → ARCHIVED
```

When a run ends, record its outcome, objective results, surviving entities, statistics, and earned unlock predicates in a durable terminal transaction. Apply that transaction to the profile exactly once, using its unique ID. Profile grants and their processed transaction/entitlement IDs must commit in the same atomic profile update. Previously checkpointed milestones retain stable entitlement IDs; terminal processing grants only outstanding credit. Archive the run only after profile application is acknowledged.

If the application closes between these steps, reopening completes the pending transaction. It cannot revive the run or award the same unlock twice. The debrief may always be reopened after archival.

A terminal loss during aftermath stabilization enters `TERMINAL_PENDING` immediately after that completed step and bypasses all uncommitted salvage or reward choices. Resume preserves the aftermath phase; it cannot restart the completed encounter or grant rewards that were never secured.

### 3.6 Failures, recovery, updates, and conflicts

- Write a temporary new save, validate it, and atomically replace the active generation; retain one prior valid generation for corruption recovery.
- A crash normally resumes the latest valid snapshot. Up to the autosave interval of uncommitted tactical progress can be lost; do not promise perfect crash rollback prevention.
- When corruption forces recovery from an older generation, label the recovery and preserve the damaged record for diagnosis. Recovery is not a normal checkpoint-selection feature.
- If a required write fails, pause further state-changing actions, retain the in-memory state, explain the failure, and offer retry or a safe export. Never report a successful save when it failed.
- Include a save schema version. Migrate a copy, validate it, and replace the active file only after success. Unsupported saves show a clear compatibility message; never silently start a fresh run.
- Cloud synchronization is an expansion. If enabled, synchronize only completed generations and detect divergence by run ID and generation ancestry. Never merge two competing fuel balances or combat states; preserve both copies and ask which timeline to continue.
- Local save integrity supports reliable play, not a promise of tamper-proof competitive verification. Any later ranked mode requires a separate verification design.

### 3.7 Save acceptance checks

Before calling saving complete, verify these behaviors:

1. Suspend during incoming shells, a torpedo run, flooding, crew movement, and an aircraft return; resume with identical active entities, progress, and stores.
2. Resume a paid but unfinished repair or port installation without duplicate payment or instant completion.
3. Reload after revealing an event result, shop, or salvage offer; contents and committed outcomes remain unchanged.
4. Interrupt terminal processing before and after profile application; the run stays terminal and grants each earned item once.
5. Recover from a corrupt latest generation without silently losing the profile or replacing the run with a new one.
6. Verify that changing cosmetic/accessibility settings does not advance time, alter generated events, or consume gameplay random draws.
7. Resume an unstable ship in aftermath; hazards continue in the correct phase, and terminal loss bypasses unclaimed rewards without duplicating earlier milestone credit.
8. Resume with a fired flare, intercepted signal, partially received supplies, cleared mine lane, and off-duty watch; all costs, recipients, partial transfers, paths, and consequences remain committed once.
9. Resume an independent breakthrough campaign with no convoy records; no cargo requirement is introduced. Restore faction, layout, and its objective contract unchanged.

## 4. End game

### 4.1 Campaign objective and independent result records

The campaign's exact story and final operation are **not yet confirmed**. A run must reach the final ocean sector, complete its declared faction objective, and secure the destroyer through extraction or docking. Finishing the route is necessary, but completing every optional location or sinking every enemy is not.

**Proposed default for prototyping: breakthrough to a forward base.** Cross the marked final defense corridor, register the destroyer's passage at its far checkpoint, and hold the safe docking zone for a displayed 30 simulated seconds while meeting the stabilization conditions in Section 1.9. Unsafe conditions pause docking progress; leaving the zone resets that progress. Opponents, port identity, and briefing adapt to faction. This supplies a complete prototype win rule without assuming an always-present convoy. Other campaign contracts may replace the checkpoint objective with a strike, rescue, or relief requirement, disclosed before the run.

Each campaign contract defines required objective metrics, critical entities, allowed recovery, local-failure consequences, finale stages, and mandatory survival. Evaluate only the active contract's requirements. An ordinary independent destroyer run has no hidden minimum cargo delivery or merchant-survival condition.

**Optional convoy-relief contract:** Begin with three merchant ships carrying 40 mission-cargo units each. Its delivery requirement is at least 60 of the initial 120 units. These are proposed values for that contract only. Mission cargo is separate from ordinary supplies; spending or sacrificing it previews the remaining possible delivery against the requirement. Cargo fields are absent/inactive for contracts without delivery objectives.

Track three results independently:

- `objective_result`: incomplete, partial, completed, or irrecoverably failed.
- `flagship_result`: operational, disabled but recoverable, extracted/docked, sunk, abandoned, or captured.
- `campaign_outcome`: victory, defeat, withdrawal, or menu abandonment.

For delivery contracts, cargo registered at the destination remains delivered even if its merchant ship is later lost. Cargo on a sunk ship is lost unless an explicitly available recovery action preserves some of it. The game must not declare that objective impossible while a valid, bounded recovery or transfer can still satisfy it. Optional convoy failures in a different campaign affect that assignment and its rewards; they do not create an undeclared campaign defeat.

### 4.2 Final operation structure

The finale uses a multi-stage naval operation rather than one enemy with a larger health bar:

| Stage | Objective | Systems emphasized | Prior-run influence |
|---|---|---|---|
| 1. Find an approach | Establish a usable corridor through patrols/mines | Reconnaissance, sonar, intelligence, route choice | Scouting reveals a safer approach or enemy schedule |
| 2. Cross the defense zone | Move the destroyer and any explicitly required allies through contested water | Maneuver, AA, screening, range management | Surviving support and prior patrol disruption help |
| 3. Complete the assigned objective | Register passage at the far checkpoint in the default contract; delivery/strike/rescue in another declared contract | Positioning, damage control, prioritization, relevant mission tools | Intelligence and earlier objective flags change opportunities |
| 4. Secure the force | Reach extraction or complete secure docking with the command ship | Endurance, retreat, stabilization | Earlier corridor clearance changes the exit threat |

Stages preserve damage, ammunition, crew losses, and aircraft state. Brief planning pauses are free; actual repair, rearm, or waiting between stages has a stated cost and requires available resources. Reinforcements are finite, scheduled or conditional, and signaled when discoverable.

The final manifest records stage objectives, deadlines if any, retreat options, required survival, and completion rules. Sector choices may change force composition or approach, but cannot secretly add a new victory requirement after the player commits to the operation.

### 4.3 Victory and quality of victory

The default campaign grants victory only when all of the following hold after the simulation step resolves:

1. The active campaign contract's required objective metrics are complete; for a convoy-relief contract this includes its delivery quota.
2. The command ship has completed extraction or secure docking.
3. The command ship has positive structural hull, is not in a terminal capsize/sinking state, and retains at least one crew token capable of command or recovery.
4. Every other explicitly campaign-critical condition is satisfied.

Victory quality reflects relevant optional outcomes: crew and allied survival, rescued personnel reaching safety, extra cargo when assigned, ports preserved, and mission conduct. Use contract-appropriate distinctions such as decisive breakthrough, narrow escape, or costly relief rather than treating every success as identical.

A victory ends gameplay for that run after its terminal transaction. The player cannot continue farming encounters with a completed campaign. An endless mode would be a separate ruleset and expansion.

### 4.4 Defeat, withdrawal, and abandonment

**Defeat occurs when:**

- The command ship sinks, capsizes, or is captured.
- All crew are dead or irrecoverably incapacitated, with no valid autonomous stabilization or allied rescue that preserves the campaign.
- The mandatory objective is irrecoverably impossible; for example, delivered plus still-recoverable mission cargo falls below the delivery requirement.
- An explicitly declared campaign-critical deadline expires.
- The player selects surrender/abandon ship after no viable continuation, or loses an encounter whose briefing declared that failure terminal.

Disabled propulsion, zero ammunition, high threat, or low morale alone do not immediately end the run. Evaluate available repair, tow, support, and withdrawal options first according to their actual prerequisites.

**Withdrawal** is a deliberate end to the operation through a permitted port, evacuation, or extraction route while the campaign remains active. It preserves earned discoveries and milestone credit but awards no victory credit. Tactical retreat normally continues the run; it is not automatically campaign withdrawal.

**Menu abandonment** explicitly discards an active run through a confirmation showing its consequences. It keeps previously committed discoveries but grants no new completion reward. Exiting the application or closing a suspended game is never menu abandonment.

The default game does not transfer player control to a surviving escort after the command ship is lost. Surviving allied vessels still appear in the debrief. Flagship transfer is a possible future campaign modifier requiring its own crew, equipment, save, and outcome rules.

### 4.5 Simultaneous outcomes and edge-case precedence

Within a simulation step, resolve already-launched attacks, hazard damage, casualty transitions, cargo delivery, and extraction progress before terminal evaluation. Record all completed objective facts, then evaluate mandatory survival and campaign-critical failure conditions before victory.

If a required checkpoint is crossed, or the last required cargo is delivered, in the same step that the command ship sinks, record objective completion and command-ship loss, but the campaign outcome is **defeat** when extraction/survival was required. The debrief explicitly acknowledges the completed objective. Do not grant both victory and defeat rewards.

An incoming attack already in flight does not disappear because its firing ship was destroyed. A completed extraction does not erase lethal damage that resolved in the same step. Once a terminal outcome is committed, later queued effects cannot change it or trigger another terminal transaction.

If an objective ship must leave the map, its exit registration is a deliberate event, not removal by generic entity cleanup. Aircraft still airborne at a nonterminal encounter exit must be recovered, transferred to an eligible source, or explicitly abandoned; the interface previews time and losses. At a terminal extraction, the manifest specifies which returning squadrons can recover to safety, and the debrief resolves the rest.

### 4.6 Debrief, rewards, and lessons

The debrief presents the campaign outcome, progress against the active objective, delivery amount when applicable, fate of every friendly ship, crew casualties, survivors rescued, key route choices, resource use, and final cause of loss or success. Show a short causal chain when possible: torpedo hit → machinery flooding → pumps lost power → prolonged critical instability → capsize.

List newly unlocked options and the exact earned milestone. Record the seed, rules/content versions, starting setup, difficulty, duration, and major event timeline so the player can retry or discuss the run. Scores are secondary to mission outcomes and should not reward prolonging a battle to farm repairs, suppressions, or repeated damage.

[OPEN END-01: choose whether future campaigns permit a sacrificial mission victory without flagship survival.] Provisional default: breakthrough and convoy-relief contracts require survival; any exception must be explicit in that campaign's setup and final manifest. [OPEN STORY-01: choose the main story and final objective.] Provisional prototype default: breakthrough to a forward base, with convoy relief retained as an optional contract example.

## 5. Replayability

### 5.1 Sources of variation

| Layer | What changes between runs | What stays consistent |
|---|---|---|
| Campaign route | Branches, sector options, hazard placement, resupply access | Forward connectivity and objective rules |
| Encounters | Enemy mix, position, weather, objective variant, reinforcement timing | Capability rules, threat budget, readable mission briefing |
| Events | Eligible templates, details, choices enabled by current state, follow-up chains | Authored consequences and saved commitments |
| Logistics | Optional stock, prices within bounds, salvage, service capacity | Guaranteed necessities used by viability validation |
| Crew | Names, backgrounds, traits, recruit pools | Role access and bounded skill/trait budgets |
| Player build | Ship, doctrine, equipment, specializations, support | Slot, supply, and compatibility constraints |
| Campaign response | Pursuers, port relations, rescue consequences, finale modifiers | Bounded flags with clear causes |

The objective is different plans and stories, not just different enemy health values. Reconnaissance, escort defense, and gunnery/torpedo approaches should solve common objectives through different costs and priorities within the destroyer category. Distinct national appearances and layouts must support more than one viable build each.

### 5.2 Procedural generation pipeline

Generate and validate in this order:

1. Fix the faction, campaign/scenario force pools, objective contract, ruleset, difficulty, seed, and eligible starting destroyer content. Exact date tags are optional scenario flavor or challenge constraints, not default technology gates.
2. Generate the sector structure and forward route graph.
3. Place mandatory objectives, exits, baseline services, and known capability gates.
4. Construct at least one baseline-feasible route for the selected ship using guaranteed resources and a documented reserve assumption.
5. Allocate each encounter a threat budget and select compatible templates.
6. Populate optional hazards, rewards, events, shops, weather, and limited follow-up chains.
7. Validate connectivity, prerequisites, resource availability, objective capacity, and encounter counterplay.
8. Retry invalid generation deterministically up to a fixed attempt limit; use a known-valid fallback graph if attempts fail.
9. Persist the resulting graph and committed content. Reveal only the information permitted by reconnaissance.

For a prototype, generate all mandatory structure and baseline services at run creation. Optional event instances can be selected on arrival from eligible templates using their dedicated stream. Recheck their eligibility against current state; use an explicit fallback if the planned event is now impossible.

### 5.3 Fairness and anti-softlock rules

- Every normal reachable node has a forward continuation to an exit. Deliberate dead ends must be labeled one-shot optional sorties with a defined return or outcome.
- At least one baseline route is affordable from the generated starting setup and guaranteed resupply. A basic fuel offer counts only if guaranteed credits or a free entitlement make it purchasable.
- Random salvage, a possible event windfall, or an unavailable reputation discount never counts as guaranteed fuel in validation.
- Guaranteed service nodes provide the fuel/basic ammunition/repair capability assumed by the route validator; special shortages are placed only where the baseline path does not depend on them.
- A mandatory encounter cannot require an unavailable specialized weapon. Survival, evasion, support, or another route may satisfy the counterplay requirement.
- Validate starting viability separately for each faction's baseline destroyer and service access. Baseline logistics must include rations, finite ammunition where combat is mandatory, and any required resupply entitlement, as well as fuel.
- Mine placement preserves at least one navigable or support-enabled response, including turning room. A mixed air/submarine/mine encounter shares one threat budget and cannot require mutually impossible maneuvers.
- A recent signal or high-noise action may alter a bounded future encounter's weights or pursuit state. It must not bypass force eligibility, reinforcement caps, or the existing extra-interception limit.
- At least one eligible option or explicit terminal decision exists in every event state. Missing crew, destroyed equipment, or full storage cannot trap the interface.
- Objective-critical cargo and characters have stable identities; a generic despawn, event replacement, or port refresh cannot remove them.
- A route can become unviable through player choices, battle damage, or disclosed risk. The generator promises a viable starting opportunity, not a guaranteed win after any sequence of decisions.
- When distress aid exists, it is finite and has a meaningful cost. Exhausted aid leads to a clear withdrawal/defeat decision, not a repeatable resupply farm.

### 5.4 Event selection and repetition control

Each event carries theater, sector, threat, objective, faction, crew, equipment, and history prerequisites. Weight selection by eligibility, novelty, and campaign context; then normalize only among eligible events.

Use per-run cooldowns, unique-event flags, and category quotas. Avoid the same major event twice in one run unless it is an intentional follow-up. Keep a mix of combat, logistics, discovery, and difficult noncombat choices; consecutive forced combat and repeated unrewarding events have configurable limits.

Follow-up chains should be short enough to resolve within the remaining graph. If a branch is inaccessible, resolve its pending consequence through a defined alternative or mark it unresolved in the debrief. Do not strand a main quest behind an optional node that no longer exists.

### 5.5 Build diversity and tradeoffs

| Approach | Strength | Cost or vulnerability | Supporting choices |
|---|---|---|---|
| Reconnaissance and evasion | Better route information and disengagement | Lower burst damage and limited cargo space | Sensors, scouting, economical travel |
| Convoy defense | Keeps merchants alive against mixed attacks | Must spend ammo/time on protection | AA, escorts, damage control, fighter cover |
| Destroyer surface attack | Better gun solutions and coordinated torpedo opportunities | Limited heavy ordnance, AA/ASW slot tradeoffs, approach fuel | Destroyer weapon package, fire control, resupply planning |
| Endurance and salvage | Recovers from damage and maintains supplies | Slower tempo and exposure during recovery | Engineers, storage, tender access |
| Coordinated air support | Flexible scouting and distant strikes | Source range, weather, sortie stock, recovery delay | Signals, intelligence, compatible support bases |

No approach should ignore all other systems. Weather can weaken aircraft without making air investment useless for an entire campaign; armor can protect against shells while leaving flooding and logistics consequential. Balancing should preserve each approach's particular strengths.

### 5.6 Modes and difficulty

Initial modes are standard campaign, tutorial/practice, and seeded custom run. Later options include short operations, convoy-focused challenges, restricted loadouts, storm seasons, and daily/weekly shared seeds. Scheduled challenge content is a possible game feature, not a requirement for a live service.

Difficulty may alter starting reserves, threat growth, enemy coordination, warning lead time, and reward abundance. Any changes are recorded in the run ruleset. Do not remove pause or conceal essential costs to manufacture difficulty. Presentation, readability, input accommodations, and color-independent warnings remain available at every difficulty.

For comparable shared-seed runs, freeze the eligible content manifest and starting options; otherwise label the seed as shareable but not competitively equivalent. Extra unlocks must not silently change a published challenge's shops or event pool.

### 5.7 Replayability validation

Track route selection, ship/doctrine usage, purchase decisions, optional-objective engagement, win rates by ruleset, loss causes, and event repetition. Use these to find mandatory purchases, ignored upgrades, uncounterable combinations, and repetitive openings.

Evaluate decisions in context: a frequently chosen fuel purchase may be healthy logistics, while one sensor being required by every successful build may reveal a broken mandatory gate. Test the same seed with distinct builds and different seeds with the same build. Human playtests must assess whether losses were understandable and whether a second attempt suggests a different plan.

## 6. Factors, variances, and variables

### 6.1 Definitions, units, and boundaries

**Factor:** A causal input, such as sea state affecting gunnery.  
**Variable:** Stored state or a configurable parameter, such as current fuel or maximum pump rate.  
**Variance:** A bounded source of difference, such as encounter composition or a hit roll.

Use normalized fractions from 0 to 1 inside formulas where specified, percentages from 0 to 100 for readable condition/hazard values, seconds for tactical time, and hours for campaign time. Never mix units implicitly. Each variable has one authoritative owner; interface totals are derived views.

The prototype may use abstract distance units and resource units. Equipment data must name its units so a future scale change is explicit. All numeric examples below are initial tuning proposals. Human-facing sector names and `sector_*` identifiers refer to the same campaign layer. There is no second hidden region layer.

### 6.2 Campaign, economy, and objective variables

| Variable | Type / unit | Prototype default or range | Main use |
|---|---|---|---|
| `run_id`, `seed`, `rules_version` | Stable identifiers | Assigned at creation | Identity and reproducibility |
| `side_id`, `faction_id`, `destroyer_layout_id` | Validated identifiers | Allies: American/British; Axis: German/Japanese | Force eligibility, visual identity, starting configuration |
| `campaign_contract_id`, `required_objective_metrics` | Identifier and typed record | Proposed default: breakthrough checkpoint plus secure docking | Evaluate only the selected campaign's actual requirements |
| `sector_index`, `sector_count` | Integers | 1–6; count 6 | Campaign stage |
| `campaign_hours` | Nonnegative hours | Starts at 0 | Time costs, deadlines, fatigue/rations |
| `sector_threat` | Number / percentage scale | 0–100 | Patrol pressure |
| `threat_thresholds` | Ordered list | 30, 60, 85 | Pressure tiers |
| `threat_time_rate` | Threat points/hour | 2 | Time-based pressure |
| `deadline_hours` | Hours or absent | Absent in default campaign | Explicit timed variants |
| `fuel`, `fuel_capacity` | Resource units | Class/loadout dependent | Movement and fuel-powered operation |
| `requisition_credits` | Nonnegative integer | Route/setup dependent | In-run purchasing |
| `parts`, `medical` | Nonnegative units | Loadout dependent | Material repair and medical recovery |
| `rations`, `ration_policy_multiplier` | Crew-day units; multiplier | Stock setup-dependent; policy 1.0 or 0.75 | Food endurance and crew shortfall |
| `ration_demand_equivalent`, `food_shortfall` | Per-crew/group demand and accumulated shortfall | Prototype demand 1 per starting crew token; shortfall starts at 0 | Consumption, morale/rest penalties, gradual recovery |
| `ammunition[type]` | Nonnegative integers | Compatible classes only | Firing/launch eligibility |
| `intelligence`, `support_charges` | Nonnegative integers | Scenario dependent | Limited information/support actions |
| `signal_flares`, `smoke_stores` | Nonnegative units | Loadout dependent | Finite signals and concealment |
| `distress_uses_remaining` | Nonnegative integer | 1 per standard campaign | Bounded emergency service |
| `cargo_capacity`, `cargo_used` | Capacity units | Class dependent | Storage tradeoffs |
| `mission_cargo_initial` | Integer cargo units or inactive | Optional convoy contract: 120 | Fixed ledger only when a delivery objective applies |
| `mission_cargo_required` | Integer cargo units or inactive | Optional convoy contract: 60 | Delivery threshold; not a universal win rule |
| `mission_cargo_delivered` | Integer cargo units or inactive | Optional convoy contract: 0–120 | Registered delivery progress |
| `mission_cargo_recoverable` | Integer cargo units or inactive | Undelivered cargo still capable of delivery: eligible surviving ships, the pre-rendezvous convoy, and declared recovery records; excludes delivered cargo | Irrecoverability check only for an active delivery requirement |
| `reputation[faction]` | Bounded integer | −100 to 100 | Service/choice eligibility |
| `event_flags`, `objective_flags` | Keyed records | Content-defined | Persistent consequences |

Fleet resources are owned by specific vessels or support sources. On the map, a force-wide display may sum them, but transfer requires a permitted resupply action. During combat, escorts cannot fire ammunition that exists only in the flagship's hold. Travel previews include the assigned fuel contributions of all accompanying player-controlled vessels; merchant endurance uses its campaign definition and cannot become a hidden extra player bill.

### 6.3 Ship, compartment, and crew variables

| Group | Variables | Bounds / meaning |
|---|---|---|
| Structure | `hull_current`, `hull_max`, `armor[zone]` | Hull 0–maximum; armor nonnegative |
| Buoyancy | `flood_fraction`, `critical_flood_timer` | Flood fraction 0–1; prototype foundering at 0.80 for 20 seconds, reset below 0.70 |
| Movement | `position`, `heading`, `speed`, `speed_order`, `turn_rate` | Class- and damage-limited |
| Power | `generation_available`, `power_allocated[system]`, `shed_priority` | Allocation never exceeds current capacity |
| Emergency reserve | `auxiliary_energy_remaining` | Finite energy for explicitly compatible essentials |
| Systems | `condition`, `field_repair_ceiling`, `required_staff`, `power_demand` | Condition 0–100; ceiling initially 70% |
| Compartments | `volume_capacity`, `water_volume`, `breach_rate`, `fire_intensity`, `smoke` | Water bounded by volume; hazard scales 0–100 |
| Connections | `door_state`, `bulkhead_tier`, `watertight_integrity`, `fire_resistance`, `closure_time`, `traversal_time`, `remote_power_required` | Open/closed/blocked, upgrade level, bounded protection, manual/remote behavior |
| Stability | `stability_reserve`, `critical_stability_timer` | Reserve 0–100; prototype critical below 10 for 20 seconds |
| Crew survival | `health`, `injury_state`, `stabilization_time_remaining` | Health 0–100; explicit wound/casualty state |
| Crew performance | `fatigue`, `morale`, `skill[role]`, `traits` | Fatigue/morale 0–100; bounded skills |
| Crew task | `location`, `path`, `assignment`, `setup_progress`, `task_progress` | One primary task per token |
| Living spaces | `berth_capacity`, `mess_capacity`, `occupants`, `recovery_rates`, `morale_rest_target` | Finite slots; prototype morale target 70; no remote station bonuses |
| Watch plans | `normal_watch`, `battle_stations`, `manual_overrides` | Saved assignments; execution still requires travel/setup |

Critical stability recovery must rise above a separate safe threshold, initially 15, to reset the countdown. This hysteresis prevents a tiny fluctuation around 10 from repeatedly granting a fresh grace period.

### 6.4 Tactical and environmental variables

| Group | Variables | Design role |
|---|---|---|
| Detection | `contact_state`, `contact_quality`, `last_seen_tick`, `signature` | Information and firing solutions |
| Sensors | `radar_tier`, `sonar_tier`, `sensor_mode`, `search_range`, `update_interval`, `track_capacity`, `emission_strength` | Upgradeable capabilities with independent condition, staffing, power, and exposure |
| Gunnery | `range`, `bearing_error`, `arc`, `reload_remaining`, `aim_solution` | Attack eligibility and accuracy |
| Ordnance | `projectile_position`, `velocity`, `damage`, `penetration`, `fuse_state` | Persistent attack resolution |
| Submarines | `depth_state`, `battery`, `acoustic_signature`, `torpedoes` | Stealth/endurance tradeoffs |
| Aircraft | `sortie_state`, `aircraft_count`, `readiness`, `endurance_remaining`, `recovery_source` | Support lifecycle |
| Escort | `stance`, `protected_entity`, `readiness`, `stores`, `ability_cooldowns` | Abstract allied behavior |
| Weather | `visibility`, `sea_state`, `wind`, `precipitation`, `cloud_cover` | Detection, movement, gunnery, aircraft |
| Day/night | `light_level` | Lookout effectiveness and concealment |
| Geography | `water_depth`, `coast_proximity`, `mine_risk`, `cover_zones` | Route and weapon restrictions |
| Mines | `mine_id`, `position`, `trigger_type`, `armed_state`, `identified_by`, `cleared_lane_records` | Persistent hazards; no rearming after destruction |
| Signals | `signal_id`, `source`, `channel`, `position`, `strength`, `expiry_tick`, `recipients`, `response_ids` | Saved detection, finite duration, and deduplicated help/pursuit |
| Exposure | `local_signature`, `pursuit_flags`, `response_pool_remaining` | Local information and bounded later consequences, distinct from sector threat |
| Replenishment | `transfer_id`, `source_id`, `recipient_id`, `reserved_units`, `delivered_units`, `remaining_time` | Stock ownership and resumable partial delivery |
| Objectives | `delivery_progress`, `zone_occupancy`, `extraction_progress`, `wave_index` | Non-annihilation encounter resolution |
| Escape | `retreat_progress`, `pursuit_quality`, `escape_route_valid` | Transparent disengagement |

Environmental conditions have state and forecast quality. They change according to the scenario's bounded weather model, not by an independent weather reroll every tactical step. A major weather change is telegraphed when a forecast or observation could reveal it.

### 6.5 Initial formulas and resolution rules

These are executable design intentions expressed as pseudocode, with coefficients stored in tuning data. `clamp(x, a, b)` restricts a value to the stated range.

**A. Strategic travel cost**

```text
travel_hours = edge_distance / effective_transit_speed
vessel_travel_fuel = edge_distance × fuel_per_distance
                     × speed_multiplier × weather_multiplier × damage_multiplier
force_travel_fuel = sum(vessel_travel_fuel for fueled accompanying vessels)
```

Distance and speed use the same scale. `effective_transit_speed` is the independent destroyer's eligible speed, or the slowest required accompanying vessel's speed when traveling as a force. Check each contributing vessel's accessible fuel before departure, or perform an explicit transfer first. Tactical maneuver/generator fuel is metered separately by simulated seconds; strategic travel cost already includes normal machinery use during that travel and must not be charged twice. Round only at the resource system's declared precision.

**B. Threat update**

```text
threat_after = clamp(threat_before + 2 × elapsed_campaign_hours
                     + action_signature_points - committed_intelligence_reduction, 0, 100)
next_sector_start = clamp(next_sector_base_threat + 0.25 × threat_at_exit, 0, 100)
```

An action's signature impulse is applied once per committed action ID. Prototype examples are 3 points for a conspicuous departure and 4 points for a loud engagement; ordinary passive map inspection contributes zero. Combat time contributes only its actual duration. Intelligence reductions consume a finite resource or unique opportunity.

**C. Working system output**

```text
if any mandatory prerequisite is missing: output = 0
else:
  condition_factor = condition_percent / 100
  staffing_factor = clamp(effective_staff / required_staff, 0, 1)
  output = base_output × condition_factor × power_factor × staffing_factor
           × skill_multiplier × fatigue_multiplier × morale_multiplier × hazard_multiplier
```

All multipliers are bounded and nonnegative. Equipment that supports reduced manual operation defines its own minimum staffing and output branch. Required staffing is positive for crew-operated systems; automatic systems use a declared factor of 1. Skill cannot make output infinite or produce negative reload times.

Morale/fatigue modifiers use only the actual assigned crew and a documented bounded aggregation, initially a staffing-weighted mean. Food shortfall modifies morale change and fatigue recovery in the prototype rather than also applying a third hidden direct output penalty. Automatic systems have crew morale/fatigue factors of 1. Recovery rates apply per elapsed hour/second under the clock conversion, never once per menu visit.

**D. Surface hit probability**

```text
if target is not eligible: attack cannot fire
else:
  p_hit = clamp(base_accuracy × track_factor × range_factor × weather_factor
                × fire_control_factor × target_maneuver_factor, 0.05, 0.95)
```

The prototype 5% floor and 95% ceiling apply only to eligible probabilistic surface-gunnery attacks. They do not give an out-of-range or deep-submerged target a chance to be hit, and do not apply to every weapon type. Torpedoes and area depth-charge attacks have their own travel/intersection model.

**E. Armor and penetration**

```text
penetration_margin = attack_penetration - effective_armor_at_impact
damage_multiplier = lookup_penetration_band(penetration_margin)
structural_damage = base_damage × damage_multiplier
```

Prototype bands use separate nonpenetrating, partial, and penetrating outcomes. Local systems, crew, fire, and breaches use the hit's effect definition. Avoid subtracting an armor number from an unrelated damage scale without a declared conversion.

**F. Floodwater and stability**

```text
water_next = clamp(water_current
                   + (ingress + adjacent_inflow - adjacent_outflow - pumping) × dt,
                   0, compartment_volume)
flood_fraction = sum(water_volume) / sum(compartment_volume)
list_fraction = abs(sum(side_sign × lateral_weight × water_volume)) / ship_list_scale
stability_reserve = clamp(100 - 60 × flood_fraction - 60 × list_fraction, 0, 100)
```

Flow rates use volume per second and `dt` is seconds. Compute all connection flows from the same pre-step snapshot and cap transfers by source water and destination space, preserving mass. Excess ingress at capacity is handled as spill/pressure by the breach model, not silently transferred into hull healing. Evaluate the independent total-flooding countdown from Section 1.9 as well as stability: balanced flooding can cause foundering without causing capsize. Stability coefficients, buoyancy thresholds, and compartment weights require tuning for each layout. Floodwater may also cause direct local/structural effects through declared hazard rules.

**G. Field repair**

```text
repairable_points = max(0, field_repair_ceiling - current_condition)
restored_points = min(repair_rate × dt, repairable_points, affordable_points_from_parts)
```

Reserve or consume parts in fixed work increments; partial work is saved. Repairing one system cannot spend parts already reserved for another. Port overhaul uses a separate ceiling of maximum condition and its own cost.

**H. Event weighting**

```text
weight(event) = base_weight × sector_fit × context_fit × novelty_factor
p(event) = weight(event) / sum(weight of all eligible events)
```

Ineligible events have weight zero. An empty eligible pool selects a known-valid fallback; it never divides by zero. Once selection is committed, later rechecks affect only still-uncommitted choices according to explicit fallback rules.

### 6.6 Order of operations and invariant rules

At each tactical step:

Use the completed start-of-step state to determine eligibility for continuous work such as repair, suppression, pumping, generator output, and crew task bonuses. Cap the work by available supplies and apply its results at the boundary. Crew arriving during the step begin their new task next step; newly created hazards begin continuous spread/damage next step, although the attack's immediate damage applies now. If fuel funds only part of a step, prorate supported continuous output to the funded duration and disable fuel-powered output at depletion. This fixed-step convention avoids granting a full step of work after supplies are exhausted.

1. Read queued player orders and scheduled AI decisions from the completed prior state; validate their prerequisites.
2. Allocate power and tasks, advance crew setup/movement and ship maneuver, and meter ongoing fuel, ration demand, and authorized partial-transfer work. Accrue eligible rest and meal effects using start-of-step assignments.
3. Update observations/contact tracks and eligible signal reception; advance reloads and sortie/ability states; create newly valid launches/signals and consume their costs. Discrete launches recheck prerequisites after that step's resource metering, so a newly unpowered mount cannot fire under a power requirement. Newly created signals are evaluated for reception on the next step.
4. Advance all projectiles and aircraft attacks, resolve eligible mine triggers and expire effects; resolve impact events for this step as a batch.
5. Apply damage, hazard creation, start-of-step-eligible firefighting/repair work, water flows, and casualty updates. A team incapacitated by this step's impact keeps only its already-accrued work for this step and provides no work next step; do not retroactively erase completed work or grant the replacement team an extra step.
6. Update objective and extraction progress, campaign-time contribution, threat contributions, and persistent statistics.
7. Check irrecoverable failure and mandatory survival, then victory or local encounter completion; commit at most one terminal result.
8. Publish the completed state to the interface and create a save snapshot if due.

Tie-breaking among actions with the same timestamp uses a stable entity/action order documented by the implementation. It must not vary with rendering speed. Already-launched simultaneous attacks resolve even if their source is lost in that step; newly queued actions from a previously disabled source do not launch.

**Invariants:** resources never become negative; a crew token has one location/task; a weapon spends ammo once per launch; a sortie cannot exist twice; cargo cannot be both delivered and aboard a ship; dead escorts supply no abilities; destroyed entities persist only as declared wrecks/effects; terminal rewards apply once; pause advances no simulation; render frame rate changes no gameplay result. Sector transitions refill no stocks; one mine detonates once; one signal creates each recipient response at most once; a transfer unit belongs to one inventory; faction membership and optional cargo rules cannot change implicitly; room occupancy grants no simultaneous remote-station bonus.

### 6.7 Content record templates

Use these as documentation contracts; final serialization format and field names may change with the engine.

```yaml
event:
  id: distress_tanker_01
  tags: [atlantic_campaign, rescue, logistics]
  prerequisites:
    sector_min: 2
    sector_max: 4
    unique_per_run: true
  choices:
    - id: rescue_crew
      requires: {free_passenger_capacity: 4}
      guaranteed_cost: {campaign_hours: 2}
      outcome:
        survivors_added: 4
        flags_set: [tanker_crew_rescued]
      risk_disclosure: extra_time_increases_sector_threat
    - id: leave
      requires: {}
      guaranteed_cost: {}
      outcome:
        flags_set: [tanker_rescue_declined]
  fallback_event: empty_patrol_lane
```

```yaml
encounter:
  id: convoy_submarine_screen_01
  primary_objective: move_two_merchants_to_exit
  optional_objective: disable_or_sink_attacker
  mandatory_kill: false
  threat_budget: 8  # abstract encounter points
  enemy_pool: [submarine_early_patrol]
  eligible_player_responses: [screen, evade, depth_charge, available_air_support]
  max_reinforcement_waves: 0
  withdrawal:
    allowed: true
    consequence: unresolved_merchants_follow_declared_escape_rule
  terminal_on_local_failure: false
  reward_pool: convoy_screen_standard
```

Every encounter implementation must replace semantic placeholders such as `declared_escape_rule` with a concrete manifest rule before shipping. An event validator rejects missing referenced content, impossible costs, invalid probabilities, absent fallback choices, and rewards with no capacity-resolution behavior.

Ship definitions additionally require compartment graph, class tags, role limits, starting systems, station requirements, firing arcs, resource capacities, critical-stability parameters, allowed equipment, starting-budget cost, and visual identity. Crew definitions require role/trait rules and living/dead references that respect event eligibility.

Destroyer definitions also require faction eligibility, silhouette/layout reference, living-space capacities, door upgrade branches, normal/battle watch defaults, and local store ownership. Faction data separates visual/narrative identity from a proposed mechanical starter package. Signals, minefields, and transfers require the persistent identifiers and lifecycle fields in Section 6.4 before those encounters are considered implemented.

### 6.8 Distinct expansions requiring later specifications

**Playable submarine:** Outside the confirmed destroyer game. If separately chosen later, define battery charging, air endurance, depth, pressure hull, stealth, torpedo solutions, underwater damage control, and a compatible campaign. [OPEN EXP-01: whether to pursue this expansion at all.] Default: deferred; it cannot delay core enemy-submarine encounters or consume the four-faction destroyer scope.

**Managed carrier:** Define deck capacity, aircraft reserves, spotting/launch/recovery cycles, deck fire, hangar damage, pilot representation, and strike coordination. [OPEN EXP-02: direct deck management versus abstract air wing.] Default: retain abstract support until surface combat is proven.

**Additional geographic campaigns:** Define scenario-compatible forces, climate, geography, ports, mission themes, and original events. Exact historical dates remain optional. The four confirmed faction choices must already work in the core campaign structure; a later theater expansion is not a prerequisite for Japanese or German play. [OPEN EXP-03: additional geographic campaign.] Default: defer detailed map selection until the initial content workload is measured.

**Other deferred systems:** Multiplayer, real-time global strategy, individual simulation of every sailor, detailed ballistic physics, free-roaming ocean navigation, and unrestricted procedural narrative are outside the initial blueprint's implementation scope. They require separate value/scope decisions rather than implicit commitments.

### 6.9 Cross-system acceptance scenarios

| Scenario | Required observable result |
|---|---|
| Pause during fire, flooding, reload, retreat, and aircraft flight | Every timer stops; queued orders remain editable |
| Main battery has a tracked deep submarine target | Fire order rejected with a compatible-target explanation |
| Non-ASW ship reaches a mandatory submarine encounter | A viable mission response exists without requiring a kill |
| Last torpedo launches, then its target sinks | Torpedo remains in flight under its rules; ammunition is not refunded |
| Generator failure leaves pumps unpowered | Priority shedding is shown; emergency/manual alternatives follow equipment rules |
| Crew reassigned between two guns | Travel/setup delay applies; only one station receives that token's bonus |
| Last enemy withdraws while flagship is flooding | Stabilization continues; no free repair or automatic travel |
| Hidden submarine remains after completed escape | Encounter ends through withdrawal; no hidden-contact stalemate |
| Fuel reaches zero with no tow or support left | A clear run-ending/rescue decision exists; no endless empty map |
| Escort sinks with a protection ability queued | Future ability is canceled; already-created effects follow their duration rules |
| Aircraft are returning when player exits an encounter | Recover, transfer, or abandon is resolved explicitly |
| Delivered cargo reaches quota as flagship sinks | Record delivery success and one campaign defeat under default survival rules |
| Two field repairs compete for the last spare part | Only the affordable/reserved work completes; inventory never goes negative |
| Reopen shop, event result, or salvage screen | No stock refresh, reroll, duplicate recovery, or repeat reward |
| Generator produces an invalid mandatory route | Deterministic retry or known-valid fallback is used before presentation |
| Critical stability fluctuates around its threshold | Countdown obeys hysteresis; tiny oscillations cannot reset it indefinitely |
| All compartments flood evenly while hull remains positive | The independent foundering countdown causes sinking; balance does not preserve buoyancy |
| Start one seeded run with each of the four baseline factions | Valid friendly ports, eligible opponents, a destroyer layout, and a feasible starting route exist for each |
| Increase radar tier while holding power/staffing fixed | Only declared detection/track behavior changes; no shield or hull is added |
| Spend six depth charges and eight fuel, then change sectors | Exact remaining stores persist; the next encounter reads them unchanged |
| Signal an ally while an eligible hostile receiver is nearby | Flare/transmission costs occur once; both reception and delayed responses obey their own rules |
| Fire a flare with no eligible friendly receiver | No ally appears; the flare is still spent and exposed observers can react |
| Pause with incoming ordnance, a lit flare, a mine encounter, and a crew member en route to the mess | All movement, effect lifetime, consumption, reload, and recovery progress stop |
| A crew token rests in a full-capacity common room | Only admitted occupants gain recovery; their former stations lose their bonuses |
| Toggle reduced/normal rations repeatedly | Accumulated consumption and food shortfall persist; no free feeding or recovery |
| Interrupt replenishment after a partial delivery | Delivered stock belongs only to the receiver; remaining stock and payment obligations follow the saved contract |
| Disable remote doors during a nearby flood | Reachable intact manual controls remain usable; closure and crew escape rules remain visible |
| Lose an optional convoy in an independent breakthrough run | Apply local losses and rewards; do not trigger an undeclared cargo-based campaign defeat |

### 6.10 Balance questions and measurement plan

Measure encounter duration, meaningful pauses, time spent with no useful action, resource use per sector, damage-control recovery, route diversity, assigned-allies survival, crew workload, and causes of abandonment. Compare these across factions, destroyer layouts, builds, and difficulty settings. Also inspect ration shortfall, rest usage, ammo conservation, signal outcomes, mine-route choices, and the reason a replenishment stop was selected.

Initial hypotheses to test:

- A typical encounter lasts two to six simulated minutes and asks for several meaningful command decisions.
- A damaged ship can often recover enough function to continue, but repeated hits create real port dependence.
- At least two plausible builds per ship can complete the default campaign without a mandatory rare item.
- Successful routes vary in combat frequency, service usage, and optional missions.
- A player can identify a contributing decision or signaled danger after most defeats.

These are evaluation questions, not acceptance quotas that justify distorting results. Use observed problems to revise tuning. Do not solve pacing issues simply by raising rewards until resource management becomes irrelevant.

### 6.11 Open-decision register

| ID | Decision / work needed | Provisional default | Revisit when |
|---|---|---|---|
| SET-01 | Geographic scenario and visual reference selections | Four confirmed factions; recognizable WWII destroyers; exact historical statistics/date gates unnecessary | Before detailed narrative/art production |
| FACTION-01 | Strength of mechanical differences between faction starter packages | Comparable budgets and access to every core function; optional emphases in Section 1.1 | Four-layout comparison and early playtests |
| STORY-01 | Main story, reason to cross sectors, and final operation | Proposed breakthrough to a forward base; convoy relief is an optional contract | Before campaign narrative production |
| CTRL-01 | Tactical chart movement detail | Continuous relative movement with readable range bands | Combat sandbox playtest |
| CREW-01 | Token count and specialist-team representation | Six starter tokens, eventual six to ten | Compartment workload test |
| ECON-01 | Ammo-class granularity and inventory capacity units | Main, secondary, AA, torpedo, depth-charge classes | Vertical-slice logistics test |
| SCOPE-01 | Campaign duration and number of destroyer layouts | Six sectors; four confirmed factions with baseline destroyers; no playable capital-ship progression | Completed vertical slice |
| END-01 | Sacrificial victory in other campaigns | Survival required for prototype breakthrough and convoy relief | Additional campaign design |
| CREW-02 | Common-area capacities, morale/fatigue curves, and individual-versus-team tokens | Six specialist tokens, limited berths/mess seats, time-based bounded recovery | Crew/layout prototype |
| ECON-02 | Replenishment rates, ration penalties, and local store-loss tuning | Explicit transfers; one ration stock; no free sector resets | Logistics and recovery playtests |
| SIGNAL-01 | Exposure ranges, response delays, and patrol consequences | Finite signals, eligible receivers, bounded pursuit/reinforcement | Signal and mixed-threat playtests |
| MINE-01 | Mine clearance capabilities and additional trigger types | Contact mines, marked/uncertain lanes, evasion or compatible support | Basic minefield playtest |
| BOARD-01 | Whether capture/boarding becomes a full tactical system | Optional disabled-vessel event only; real-time boarding deferred | After core combat and crew workload are understood |
| META-01 | Exact ship/doctrine unlock predicates | Horizontal unlocks for demonstrated milestones | Full campaign progression review |
| SAVE-01 | Engine/platform file format and migration support window | Versioned atomic local saves; one recovery generation | Engine/platform selection |
| ACCESS-01 | Input, readability, and non-color warning standards | Remapping, scalable text, explicit icons/text, full pause | First interface prototype |
| BAL-01 | Coefficients, threat thresholds, and encounter budgets | Values in Section 6 are provisional | Every milestone playtest |
| EXP-01 | Whether a player-submarine expansion is wanted | Outside confirmed destroyer scope; deferred | Destroyer campaign validation |
| EXP-02 | Managed carrier control depth | Abstract aircraft support first | Air-support workload test |
| EXP-03 | Additional geographic campaign | Four factions already supported; defer extra geography | Initial campaign content estimate |

### 6.12 Revision workflow and expansion placeholders

For each revision, record the changed rule, reason, affected systems/content, save implications, and validation performed. Major behavior changes increment the document's minor version; clarifications and tuning corrections may use patch versions. Stable decision IDs remain searchable even after resolution.

| Version | Date | Change | Validation status |
|---|---|---|---|
| 0.1 | 2026-09-11 | Initial six-part foundation: naval core loop, progression, saves, endings, replayability, state/tuning contracts | Design consistency review only; no playable implementation or balance validation yet |
| 0.2 | 2026-09-11 | Applied user direction: four factions, destroyer-only command, visual authenticity over exact statistics, ocean sectors, independent campaign contracts, sensor/door upgrades, living spaces, rations, mines, signals, and persistent cause/effect rules | Markdown and cross-system consistency review; no playable/balance validation. Version 0.1 preserved under `revisions/`. Future implementation save contracts must include the new state and renamed sector fields; no existing game saves have been migrated. |

**Next design artifacts to add or link:**

- [TBD] Four-faction destroyer layout comparison, visual references, and starting loadout tables.
- [TBD] Combat equipment catalog with compatible targets, costs, ranges, arcs, and rates.
- [TBD] Crew roles, traits, injuries, specializations, normal/battle watches, and common-area recovery curves.
- [TBD] Port service, resource, cargo, and upgrade price tables.
- [TBD] First-sector graph and approximately 12 complete vertical-slice events.
- [TBD] Encounter manifests and AI doctrine rules, including retreat consequences.
- [TBD] Six-sector campaign outline and concrete final-operation manifest.
- [TBD] Save schema, state ownership diagram, migrations, and deterministic replay contract.
- [TBD] Visual/terminology reference sheet and narrative style guide; historical accuracy is a presentation reference, not a balance constraint.
- [TBD] Flare/radio/sensor exposure records, minefield layouts, and interrupted-replenishment examples.
- [TBD] Interface wireframes for chart, cutaway, port, route preview, and debrief.
- [TBD] Playtest notes and balance changes tied to observed player decisions.

The next design step is one complete destroyer layout with crew stations, living spaces, weapon stores, power demands, and an example sequence of encounters. Use it to test the decisions below on paper before broadening the roster. Milestone A remains the first implementation target.

### 6.13 Gap review against the clarified game direction

| Area reviewed | Gap in version 0.1 | Resolution in version 0.2 / remaining work |
|---|---|---|
| Player identity | Expanded player command into cruisers and battleships | Player remains a destroyer commander; larger ships stay in the encounter/support roster |
| Factions | No playable four-faction structure or side-aware route services | American/British and German/Japanese selection is explicit; package balance remains open |
| Authenticity | Required a date-bounded Atlantic equipment set | Preserve recognizable design and physical cause/effect; relax exact historical stats and dates |
| Campaign story | Assumed mandatory convoy relief for every run | Separate story/objective contracts; choose the main finale under STORY-01 |
| Ocean progression | Used generic regions and underdefined geography/event distinction | Explicit sectors containing locations, with randomized eligible events and onward exits |
| Pause and engagement readability | Core clock existed, but concurrent warnings and command behavior needed detail | Incoming torpedoes, reloads, hazards, fuel burn, paths, standing orders, and optional auto-pause defined |
| Radar, sonar, and protection | Sensors listed without clear upgrade branches or shield distinction | Defined sensor/door/pump/power options; radar never absorbs damage |
| Personnel and common areas | No functional berthing/mess/watch rules | Occupancy, travel, staffing losses, bounded recovery, and ration/time costs added |
| Resources | Provisions lacked consumption rules; capacity and morale were easy to conflate with stocks | Ration demand, shortfall, policy, conditional recovery, explicit transfers, and stock/capacity/condition categories added |
| Mines and mixed threats | Mines were named but had no encounter lifecycle | Persistent hazards, detection/clearance limits, safe-response generation, and combined threat budgets added |
| Flares and communications | No reception or unwanted-attention contract | Finite signals, eligible recipients, delayed assistance, exposure, and saved pursuit consequences added |
| Cause and effect | Examples did not form a consistent action/carryover contract | Immediate costs, execution, risks, persistent state, recovery options, and consequence log defined |
| Save fidelity | New systems had no saved-state ownership | Faction/contracts, watches, rations, signals, mines, and partial transfers added to save tables and checks |
| Full functional coverage | Naval equivalents and deliberate deferrals were not enumerated | Section 1.17 records included functions and open boarding/capture scope |

**Highest-priority unresolved decisions:** the main mission and why the destroyer must keep moving; faction/layout differentiation; the amount of crew micro-management; and resource/recovery pacing. Prototype defaults make these reviewable, but no tuning value or proposed faction advantage should be treated as approved solely because it appears here.
